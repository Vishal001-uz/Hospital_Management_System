package com.hospital.queue.token.controller;

import com.hospital.queue.token.dto.TokenRequest;
import com.hospital.queue.token.entity.Token;
import com.hospital.queue.token.service.TokenService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/tokens")
@RequiredArgsConstructor
@Tag(name = "Tokens", description = "Token booking and management APIs")
public class TokenController {

    private final TokenService tokenService;

    @PostMapping
    @Operation(summary = "Book a new token for a patient with a doctor")
    public ResponseEntity<Token> bookToken(@Valid @RequestBody TokenRequest request) {
        return ResponseEntity.ok(tokenService.bookToken(request));
    }

    @GetMapping("/{tokenId}")
    @Operation(summary = "Get token by ID")
    public ResponseEntity<Token> getById(@PathVariable Long tokenId) {
        return ResponseEntity.ok(tokenService.getById(tokenId));
    }

    @GetMapping("/doctor/{doctorId}")
    @Operation(summary = "Get all today's tokens for a doctor")
    public ResponseEntity<List<Token>> getByDoctor(@PathVariable Long doctorId) {
        return ResponseEntity.ok(tokenService.getTokensByDoctor(doctorId));
    }

    @PutMapping("/next/{doctorId}")
    @Operation(summary = "Advance to next patient in queue")
    public ResponseEntity<?> nextPatient(@PathVariable Long doctorId) {
        Token next = tokenService.nextPatient(doctorId);
        if (next == null) {
            return ResponseEntity.ok(Map.of("message", "Queue is empty, no more waiting patients"));
        }
        return ResponseEntity.ok(next);
    }

    @PutMapping("/cancel/{tokenId}")
    @Operation(summary = "Cancel a token")
    public ResponseEntity<Token> cancelToken(@PathVariable Long tokenId) {
        return ResponseEntity.ok(tokenService.cancelToken(tokenId));
    }

    @GetMapping("/{tokenId}/wait-time")
    @Operation(summary = "Get estimated waiting time for a token")
    public ResponseEntity<Map<String, Object>> getWaitTime(@PathVariable Long tokenId) {
        Token token = tokenService.getById(tokenId);
        int waitMin = tokenService.calculateEstimatedWait(token);
        return ResponseEntity.ok(Map.of(
                "tokenId", tokenId,
                "tokenNumber", token.getTokenNumber(),
                "status", token.getStatus(),
                "estimatedWaitMinutes", waitMin
        ));
    }
}

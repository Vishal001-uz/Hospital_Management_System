package com.hospital.queue.token.service;

import com.hospital.queue.doctor.entity.Doctor;
import com.hospital.queue.doctor.repository.DoctorRepository;
import com.hospital.queue.exception.ResourceNotFoundException;
import com.hospital.queue.notification.service.NotificationService;
import com.hospital.queue.patient.entity.Patient;
import com.hospital.queue.patient.repository.PatientRepository;
import com.hospital.queue.token.dto.TokenRequest;
import com.hospital.queue.token.entity.Token;
import com.hospital.queue.token.enums.TokenStatus;
import com.hospital.queue.token.repository.TokenRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class TokenService {

    private final TokenRepository tokenRepository;
    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;
    private final NotificationService notificationService;

    @Transactional
    public Token bookToken(TokenRequest request) {
        LocalDate today = LocalDate.now();

        Patient patient = patientRepository.findById(request.getPatientId())
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found"));
        Doctor doctor = doctorRepository.findById(request.getDoctorId())
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found"));

        // Check for duplicate active token
        tokenRepository.findActiveTokenForPatientAndDoctor(patient.getId(), doctor.getId(), today)
                .ifPresent(t -> { throw new IllegalStateException("Patient already has an active token for this doctor today (Token #" + t.getTokenNumber() + ")"); });

        // Auto-increment token number
        int nextNumber = tokenRepository.findMaxTokenNumberByDoctorAndDate(doctor.getId(), today) + 1;

        Token token = Token.builder()
                .tokenNumber(nextNumber)
                .status(TokenStatus.WAITING)
                .patient(patient)
                .doctor(doctor)
                .tokenDate(today)
                .build();

        Token saved = tokenRepository.save(token);
        log.info("Token #{} booked for patient {} with Dr. {}", saved.getTokenNumber(), patient.getName(), doctor.getName());

        // Send booking confirmation
        notificationService.sendBookingConfirmation(saved);

        return saved;
    }

    public List<Token> getTokensByDoctor(Long doctorId) {
        return tokenRepository.findByDoctorIdAndTokenDateOrderByTokenNumberAsc(doctorId, LocalDate.now());
    }

    public Token getById(Long tokenId) {
        return tokenRepository.findById(tokenId)
                .orElseThrow(() -> new ResourceNotFoundException("Token not found with id: " + tokenId));
    }

    @Transactional
    public Token nextPatient(Long doctorId) {
        LocalDate today = LocalDate.now();

        // Complete current in-progress
        tokenRepository.findInProgressByDoctorAndDate(doctorId, today).ifPresent(current -> {
            current.setStatus(TokenStatus.COMPLETED);
            current.setCompletedAt(LocalDateTime.now());
            tokenRepository.save(current);
            log.info("Token #{} completed", current.getTokenNumber());
        });

        // Find next waiting
        Token next = tokenRepository.findFirstWaitingByDoctorAndDate(doctorId, today)
                .orElse(null);

        if (next == null) {
            log.info("Doctor {} queue is empty", doctorId);
            return null;
        }

        next.setStatus(TokenStatus.IN_PROGRESS);
        Token saved = tokenRepository.save(next);
        log.info("Token #{} now in progress for Dr. {}", saved.getTokenNumber(), saved.getDoctor().getName());

        // Notify patient it's their turn
        notificationService.notifyTurnNow(saved);

        // Check if someone approaching (3 ahead)
        List<Token> waiting = tokenRepository.findByDoctorIdAndTokenDateOrderByTokenNumberAsc(doctorId, today)
                .stream().filter(t -> t.getStatus() == TokenStatus.WAITING).toList();
        if (!waiting.isEmpty()) {
            notificationService.notifyTurnApproaching(waiting.get(0));
        }

        return saved;
    }

    @Transactional
    public Token cancelToken(Long tokenId) {
        Token token = getById(tokenId);
        if (token.getStatus() == TokenStatus.COMPLETED) {
            throw new IllegalStateException("Cannot cancel an already completed token");
        }
        token.setStatus(TokenStatus.CANCELLED);
        Token saved = tokenRepository.save(token);
        log.info("Token #{} cancelled", saved.getTokenNumber());
        return saved;
    }

    public int calculateEstimatedWait(Token token) {
        if (token.getStatus() != TokenStatus.WAITING) return 0;
        long ahead = tokenRepository.findByDoctorIdAndTokenDateOrderByTokenNumberAsc(
                token.getDoctor().getId(), token.getTokenDate())
                .stream()
                .filter(t -> t.getStatus() == TokenStatus.WAITING && t.getTokenNumber() < token.getTokenNumber())
                .count();
        boolean hasInProgress = tokenRepository.findInProgressByDoctorAndDate(
                token.getDoctor().getId(), token.getTokenDate()).isPresent();
        return (int) (ahead + (hasInProgress ? 1 : 0)) * token.getDoctor().getAvgConsultationTime();
    }
}

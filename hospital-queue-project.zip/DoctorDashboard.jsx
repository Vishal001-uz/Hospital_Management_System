import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { queueService, tokenService, doctorService } from '../mockData';
import toast from 'react-hot-toast';
import {
  Activity, LogOut, ChevronRight, Users, Clock, CheckCircle,
  SkipForward, XCircle, Stethoscope, Bell, RefreshCw, Monitor
} from 'lucide-react';

const StatusBadge = ({ status }) => {
  const map = {
    WAITING:     <span className="badge-waiting">⏳ Waiting</span>,
    IN_PROGRESS: <span className="badge-in-progress">▶ In Progress</span>,
    COMPLETED:   <span className="badge-completed">✓ Completed</span>,
    CANCELLED:   <span className="badge-cancelled">✕ Cancelled</span>,
  };
  return map[status] || null;
};

export default function DoctorDashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const [queue, setQueue]     = useState(null);
  const [doctor, setDoctor]   = useState(null);
  const [loading, setLoading] = useState(true);
  const [advancing, setAdvancing] = useState(false);
  const [cancelling, setCancelling] = useState(null);
  const [lastRefresh, setLastRefresh] = useState(new Date());

  const doctorId = user?.doctorId;

  const fetchQueue = async () => {
    if (!doctorId) return;
    try {
      const [q, d] = await Promise.all([
        queueService.getLive(doctorId),
        doctorService.getById(doctorId),
      ]);
      setQueue(q);
      setDoctor(d);
      setLastRefresh(new Date());
    } catch (err) {
      toast.error('Failed to load queue');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!doctorId) {
      toast.error('No doctor profile linked to this account');
      setLoading(false);
      return;
    }
    fetchQueue();
    const interval = setInterval(fetchQueue, 5000);
    return () => clearInterval(interval);
  }, [doctorId]);

  const handleNext = async () => {
    setAdvancing(true);
    try {
      const result = await tokenService.nextPatient(doctorId);
      if (!result.currentToken && result.message) {
        toast.success('All patients attended! Queue is empty.');
      } else {
        toast.success(`Now serving Token #${result.tokenNumber}`);
      }
      await fetchQueue();
    } catch (err) {
      toast.error(err.message || 'Failed to advance queue');
    } finally {
      setAdvancing(false);
    }
  };

  const handleCancel = async (tokenId, tokenNumber) => {
    setCancelling(tokenId);
    try {
      await tokenService.cancel(tokenId);
      toast.success(`Token #${tokenNumber} cancelled`);
      await fetchQueue();
    } catch (err) {
      toast.error('Failed to cancel token');
    } finally {
      setCancelling(null);
    }
  };

  const handleLogout = () => { logout(); navigate('/login'); };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{background:'#080b14'}}>
        <div className="text-center">
          <div className="spinner w-10 h-10 mx-auto mb-4" style={{width:'40px',height:'40px',borderWidth:'3px'}} />
          <p className="text-slate-400">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  const stats = [
    { label: 'Total Today', value: queue?.totalToday ?? 0, icon: Users,       color: '#3b82f6' },
    { label: 'Waiting',     value: queue?.waiting?.length ?? 0, icon: Clock,  color: '#f59e0b' },
    { label: 'Completed',   value: queue?.completed ?? 0, icon: CheckCircle,  color: '#22c55e' },
    { label: 'Avg Wait',    value: `${queue?.avgWaitPerPatient ?? 10}m`, icon: Clock, color: '#8b5cf6' },
  ];

  return (
    <div className="min-h-screen flex flex-col" style={{background:'#080b14'}}>
      {/* Top nav */}
      <nav className="flex items-center justify-between px-6 py-4 flex-shrink-0"
           style={{borderBottom:'1px solid rgba(255,255,255,0.07)', background:'rgba(13,18,32,0.9)', backdropFilter:'blur(12px)', position:'sticky', top:0, zIndex:40}}>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center"
               style={{background:'linear-gradient(135deg,#1e40af,#3b82f6)'}}>
            <Activity className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="text-sm font-bold text-white">MediQueue</div>
            <div className="text-xs text-slate-500">Doctor Dashboard</div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button onClick={fetchQueue} className="btn-secondary text-xs px-3 py-2">
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
          <Link to={`/live/${doctorId}`} target="_blank" className="btn-secondary text-xs px-3 py-2 gap-1.5">
            <Monitor className="w-3.5 h-3.5" /> Live
          </Link>
          <div className="text-right hidden sm:block">
            <div className="text-xs font-semibold text-white">{user?.name}</div>
            <div className="text-xs text-slate-500">{doctor?.department}</div>
          </div>
          <button onClick={handleLogout} className="btn-secondary text-xs px-3 py-2 text-red-400 hover:text-red-300">
            <LogOut className="w-3.5 h-3.5" />
          </button>
        </div>
      </nav>

      <div className="flex-1 p-6 max-w-5xl mx-auto w-full">
        {/* Header */}
        <div className="page-header flex items-start justify-between">
          <div>
            <h1 className="page-title flex items-center gap-2">
              <Stethoscope className="w-6 h-6 text-primary-400" /> {doctor?.name || 'Doctor'}
            </h1>
            <p className="page-subtitle">{doctor?.department} • {doctor?.availableFrom} – {doctor?.availableTo}</p>
          </div>
          <span className="text-xs text-slate-500">Updated {lastRefresh.toLocaleTimeString()}</span>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {stats.map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="stat-card">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs text-slate-500">{label}</span>
                <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{background:`${color}18`}}>
                  <Icon className="w-4 h-4" style={{color}} />
                </div>
              </div>
              <div className="text-2xl font-bold text-white">{value}</div>
            </div>
          ))}
        </div>

        {/* Current patient + Next button */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Current */}
          <div className="glass-card p-6" style={{border: queue?.current ? '1px solid rgba(59,130,246,0.3)' : undefined}}>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Currently Serving</span>
            </div>
            {queue?.current ? (
              <div>
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <div className="text-5xl font-black gradient-text mb-2">#{queue.current.tokenNumber}</div>
                    <div className="text-lg font-semibold text-white">{queue.current.patient?.name}</div>
                    <div className="text-sm text-slate-400">{queue.current.patient?.phone} • Age {queue.current.patient?.age}</div>
                  </div>
                  <StatusBadge status={queue.current.status} />
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <Bell className="w-10 h-10 text-slate-700 mx-auto mb-3" />
                <p className="text-slate-500 text-sm">No patient currently in session</p>
                <p className="text-slate-600 text-xs mt-1">Click "Next Patient" to start</p>
              </div>
            )}
          </div>

          {/* Next patient preview */}
          <div className="glass-card p-6">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-2 h-2 rounded-full bg-amber-500" />
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Up Next</span>
            </div>
            {queue?.waiting?.length > 0 ? (
              <div className="space-y-3">
                {queue.waiting.slice(0, 3).map((t, i) => (
                  <div key={t.id} className="flex items-center justify-between px-4 py-3 rounded-xl"
                       style={{background:'rgba(255,255,255,0.03)', border:'1px solid rgba(255,255,255,0.06)'}}>
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-slate-600 w-4">{i + 1}.</span>
                      <div>
                        <div className="text-sm font-medium text-white">Token #{t.tokenNumber}</div>
                        <div className="text-xs text-slate-500">{t.patient?.name}</div>
                      </div>
                    </div>
                    <span className="text-xs text-amber-400">~{i * (doctor?.avgConsultationTime || 10)} min</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <CheckCircle className="w-10 h-10 text-green-700 mx-auto mb-3" />
                <p className="text-slate-500 text-sm">Queue is empty!</p>
              </div>
            )}
          </div>
        </div>

        {/* Next Patient Button */}
        <div className="flex justify-center mb-8">
          <button id="next-patient-btn" onClick={handleNext} disabled={advancing || (!queue?.current && !queue?.waiting?.length)}
                  className="btn-success text-base px-12 py-4 rounded-2xl text-lg"
                  style={{boxShadow:'0 8px 32px rgba(34,197,94,0.35)'}}>
            {advancing ? <><span className="spinner" style={{borderTopColor:'#fff'}} /> Processing...</>
                       : <><SkipForward className="w-5 h-5" /> Next Patient</>}
          </button>
        </div>

        {/* Full queue table */}
        <div className="glass-card overflow-hidden">
          <div className="px-6 py-4 flex items-center justify-between" style={{borderBottom:'1px solid rgba(255,255,255,0.06)'}}>
            <h2 className="text-sm font-semibold text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-slate-400" /> Today's Queue
            </h2>
            <span className="text-xs text-slate-500">{queue?.totalToday ?? 0} total</span>
          </div>
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Token #</th>
                  <th>Patient Name</th>
                  <th>Phone</th>
                  <th>Age</th>
                  <th>Booked At</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {queue?.waiting?.concat(queue?.current ? [queue.current] : []).sort((a,b) => a.tokenNumber - b.tokenNumber)
                  .concat(/* completed placeholder */[])
                  .map(t => (
                  <tr key={t.id}>
                    <td><span className="font-bold text-white">#{t.tokenNumber}</span></td>
                    <td className="font-medium text-white">{t.patient?.name}</td>
                    <td>{t.patient?.phone}</td>
                    <td>{t.patient?.age} yr</td>
                    <td>{new Date(t.createdAt).toLocaleTimeString()}</td>
                    <td><StatusBadge status={t.status} /></td>
                    <td>
                      {(t.status === 'WAITING') && (
                        <button onClick={() => handleCancel(t.id, t.tokenNumber)}
                                disabled={cancelling === t.id}
                                className="text-xs text-red-400 hover:text-red-300 flex items-center gap-1 transition-colors">
                          {cancelling === t.id ? <span className="spinner" style={{width:'12px',height:'12px',borderWidth:'1.5px'}} /> : <XCircle className="w-3.5 h-3.5" />}
                          Cancel
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {(!queue?.waiting?.length && !queue?.current) && (
              <div className="py-16 text-center text-slate-600">No patients in queue today</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

package com.hospital.queue.auth.enums;

public enum Role {
    ADMIN,
    DOCTOR
}

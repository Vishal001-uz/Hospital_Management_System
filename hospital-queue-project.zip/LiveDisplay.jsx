import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { queueService, doctorService } from '../mockData';
import { Activity, Clock, Users, CheckCircle, ArrowLeft } from 'lucide-react';

export default function LiveDisplay() {
  const { doctorId } = useParams();

  const [queues, setQueues]     = useState([]);
  const [doctors, setDoctors]   = useState([]);
  const [loading, setLoading]   = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [fade, setFade]         = useState(true);
  const [selectedDoctorIdx, setSelectedDoctorIdx] = useState(0);

  const isSingleDoctor = !!doctorId;

  const fetchData = async () => {
    try {
      if (isSingleDoctor) {
        const [q, d] = await Promise.all([
          queueService.getLive(doctorId),
          doctorService.getById(doctorId),
        ]);
        setQueues([{ ...q, doctor: d }]);
      } else {
        const all = await queueService.getAllLive();
        setQueues(all);
        const docs = await doctorService.getAll();
        setDoctors(docs);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const dataInterval = setInterval(fetchData, 4000);
    const timeInterval = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => { clearInterval(dataInterval); clearInterval(timeInterval); };
  }, [doctorId]);

  // Rotate through doctors every 8 seconds (for all-doctors view)
  useEffect(() => {
    if (isSingleDoctor || queues.length <= 1) return;
    const interval = setInterval(() => {
      setFade(false);
      setTimeout(() => {
        setSelectedDoctorIdx(i => (i + 1) % queues.length);
        setFade(true);
      }, 500);
    }, 8000);
    return () => clearInterval(interval);
  }, [queues.length, isSingleDoctor]);

  const displayQueue = isSingleDoctor ? queues[0] : queues[selectedDoctorIdx];

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center" style={{background:'#020409'}}>
        <div className="text-center">
          <div className="spinner w-12 h-12 mx-auto mb-4" style={{width:'48px',height:'48px',borderWidth:'3px'}} />
          <p className="text-slate-400 text-xl">Loading Live Display...</p>
        </div>
      </div>
    );
  }

  if (!displayQueue) {
    return (
      <div className="h-screen flex items-center justify-center" style={{background:'#020409'}}>
        <div className="text-center">
          <Activity className="w-16 h-16 text-slate-700 mx-auto mb-4" />
          <p className="text-gray-400 text-2xl">No queue data available</p>
          <Link to="/book" className="text-primary-400 mt-4 inline-block">← Book a Token</Link>
        </div>
      </div>
    );
  }

  const { current, waiting, completed, totalToday, doctor } = displayQueue;
  const nextTokens = waiting.slice(0, 5);

  return (
    <div className="h-screen overflow-hidden flex flex-col select-none"
         style={{background:'linear-gradient(135deg, #020409 0%, #080d1a 50%, #020409 100%)'}}>
      
      {/* Animated background */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full opacity-5 blur-3xl animate-pulse-slow"
             style={{background:'radial-gradient(circle, #3b82f6, transparent)'}} />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full opacity-5 blur-3xl animate-pulse-slow"
             style={{background:'radial-gradient(circle, #06b6d4, transparent)', animationDelay:'1.5s'}} />
        <div className="fixed inset-0 bg-grid opacity-30" />
      </div>

      {/* Top bar */}
      <div className="flex items-center justify-between px-10 py-5 flex-shrink-0 relative"
           style={{borderBottom:'1px solid rgba(255,255,255,0.06)', backdropFilter:'blur(20px)', background:'rgba(2,4,9,0.8)'}}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center"
               style={{background:'linear-gradient(135deg,#1e3a8a,#3b82f6)'}}>
            <Activity className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="text-white font-bold text-lg">MediQueue</div>
            <div className="text-slate-500 text-xs">Live Display</div>
          </div>
        </div>

        <div className="text-center">
          <div className="text-white font-semibold text-lg">{doctor?.name || 'All Doctors'}</div>
          <div className="text-slate-400 text-sm">{doctor?.department || 'Hospital'}</div>
        </div>

        <div className="text-right">
          <div className="text-white font-bold text-2xl font-mono tabular-nums">
            {currentTime.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
          </div>
          <div className="text-slate-400 text-sm">
            {currentTime.toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}
          </div>
        </div>
      </div>

      {/* Doctor tabs (multi-doctor mode) */}
      {!isSingleDoctor && queues.length > 1 && (
        <div className="flex gap-2 px-10 py-3 flex-shrink-0 overflow-x-auto"
             style={{borderBottom:'1px solid rgba(255,255,255,0.05)', background:'rgba(2,4,9,0.6)'}}>
          {queues.map((q, i) => (
            <button key={q.doctor?.id} onClick={() => { setSelectedDoctorIdx(i); setFade(true); }}
                    className={`flex-shrink-0 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                      i === selectedDoctorIdx ? 'text-white' : 'text-slate-600 hover:text-slate-400'
                    }`}
                    style={{background: i === selectedDoctorIdx ? 'rgba(59,130,246,0.15)' : 'transparent',
                            border: i === selectedDoctorIdx ? '1px solid rgba(59,130,246,0.3)' : '1px solid transparent'}}>
              {q.doctor?.name} <span className="ml-2 text-xs opacity-60">{q.waiting.length}w</span>
            </button>
          ))}
        </div>
      )}

      {/* Main display area */}
      <div className={`flex-1 flex flex-col lg:flex-row gap-8 p-10 min-h-0 transition-opacity duration-500 ${fade ? 'opacity-100' : 'opacity-0'}`}>

        {/* LEFT: Now Serving */}
        <div className="flex-1 flex flex-col items-center justify-center relative">
          {current ? (
            <div className="text-center animate-fade-in">
              {/* Animated ring */}
              <div className="relative inline-block mb-8">
                <div className="absolute -inset-8 rounded-full opacity-20 animate-pulse-slow"
                     style={{background:'radial-gradient(circle, #06b6d4, transparent)'}} />
                <div className="absolute -inset-4 rounded-full opacity-30 animate-pulse-slow"
                     style={{background:'radial-gradient(circle, #3b82f6, transparent)', animationDelay:'0.5s'}} />
                <div className="relative w-48 h-48 rounded-full flex items-center justify-center"
                     style={{background:'rgba(6,182,212,0.08)', border:'2px solid rgba(6,182,212,0.3)'}}>
                  <div className="text-center">
                    <div className="text-7xl font-black" style={{
                      background:'linear-gradient(135deg, #22d3ee, #3b82f6)',
                      WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text',
                      filter:'drop-shadow(0 0 20px rgba(34,211,238,0.5))'
                    }}>
                      {current.tokenNumber}
                    </div>
                  </div>
                </div>
              </div>

              <div className="mb-4">
                <div className="text-slate-400 text-xl font-medium uppercase tracking-[0.3em] mb-2">NOW SERVING</div>
                <div className="live-token-number font-black text-center" style={{fontSize:'clamp(3rem,10vw,7rem)'}}>
                  #{current.tokenNumber}
                </div>
              </div>

              <div className="mt-4 px-8 py-4 rounded-2xl inline-block"
                   style={{background:'rgba(59,130,246,0.1)', border:'1px solid rgba(59,130,246,0.2)'}}>
                <div className="text-2xl font-semibold text-white">{current.patient?.name || 'Patient'}</div>
                <div className="text-slate-400 text-sm mt-1">{current.patient?.phone}</div>
              </div>

              {/* Pulse dot */}
              <div className="flex items-center justify-center gap-2 mt-6">
                <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                <span className="text-cyan-400 text-sm font-medium animate-pulse">Please proceed to the room</span>
                <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              </div>
            </div>
          ) : (
            <div className="text-center">
              <div className="text-8xl mb-6 opacity-20">🏥</div>
              <div className="text-slate-500 text-3xl font-semibold">Queue Not Started</div>
              <div className="text-slate-600 text-lg mt-2">Waiting for doctor to begin</div>
            </div>
          )}
        </div>

        {/* RIGHT: Next tokens + Stats */}
        <div className="w-full lg:w-80 flex flex-col gap-6 flex-shrink-0">

          {/* Next tokens */}
          <div className="glass-card p-6 flex-1"
               style={{background:'rgba(255,255,255,0.03)', border:'1px solid rgba(255,255,255,0.07)'}}>
            <div className="flex items-center gap-2 mb-5">
              <div className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
              <span className="text-amber-400 font-semibold text-sm uppercase tracking-wider">Up Next</span>
            </div>

            {nextTokens.length > 0 ? (
              <div className="space-y-3">
                {nextTokens.map((t, i) => (
                  <div key={t.id}
                       className={`flex items-center justify-between px-5 py-4 rounded-xl transition-all duration-300 ${i === 0 ? 'glow-blue' : ''}`}
                       style={{
                         background: i === 0 ? 'rgba(59,130,246,0.12)' : 'rgba(255,255,255,0.03)',
                         border: i === 0 ? '1px solid rgba(59,130,246,0.3)' : '1px solid rgba(255,255,255,0.05)',
                       }}>
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold"
                           style={{background: i === 0 ? 'rgba(59,130,246,0.3)' : 'rgba(255,255,255,0.06)',
                                   color: i === 0 ? '#60a5fa' : '#64748b'}}>
                        {i + 1}
                      </div>
                      <div>
                        <div className={`font-bold text-lg ${i === 0 ? 'text-white' : 'text-slate-400'}`}>
                          #{t.tokenNumber}
                        </div>
                        <div className="text-slate-500 text-xs">{t.patient?.name}</div>
                      </div>
                    </div>
                    <div className={`text-right text-xs ${i === 0 ? 'text-amber-400' : 'text-slate-600'}`}>
                      ~{i * (doctor?.avgConsultationTime || 10)}m
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <CheckCircle className="w-10 h-10 text-green-600 mx-auto mb-3" />
                <div className="text-slate-500 text-sm">No more patients waiting</div>
              </div>
            )}
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: 'Waiting',   value: waiting.length, color: '#f59e0b', bg: 'rgba(245,158,11,0.1)'  },
              { label: 'Done',      value: completed,      color: '#22c55e', bg: 'rgba(34,197,94,0.1)'   },
              { label: 'Total',     value: totalToday,     color: '#3b82f6', bg: 'rgba(59,130,246,0.1)'  },
            ].map(({ label, value, color, bg }) => (
              <div key={label} className="rounded-2xl p-4 text-center"
                   style={{background: bg, border:`1px solid ${color}25`}}>
                <div className="text-3xl font-black" style={{color}}>{value}</div>
                <div className="text-xs text-slate-500 mt-1">{label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom ticker */}
      <div className="flex-shrink-0 py-3 overflow-hidden" style={{background:'rgba(59,130,246,0.08)', borderTop:'1px solid rgba(59,130,246,0.2)'}}>
        <div className="ticker-wrap">
          <div className="ticker-text text-sm text-blue-300 font-medium">
            {waiting.length > 0
              ? `🔔 Tokens waiting: ${waiting.map(t => `#${t.tokenNumber}`).join(', ')} &nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp; Total today: ${totalToday} patients &nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp; ${doctor?.name} — ${doctor?.department} &nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp; 🏥 MediQueue Hospital Token System &nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp; Auto-updates every 4 seconds`
              : `✅ No patients currently waiting — ${doctor?.name || 'All doctors'} | 🏥 MediQueue Hospital Token System | Total served today: ${completed}`
            }
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            {waiting.length > 0
              ? `🔔 Tokens waiting: ${waiting.map(t => `#${t.tokenNumber}`).join(', ')} &nbsp;&nbsp;&nbsp; |&nbsp;&nbsp;&nbsp; Total today: ${totalToday} patients`
              : `✅ No patients currently waiting`
            }
          </div>
        </div>
      </div>

      {/* Back link (subtle) */}
      <Link to="/book"
            className="fixed bottom-4 left-4 flex items-center gap-1 text-xs text-slate-700 hover:text-slate-400 transition-colors">
        <ArrowLeft className="w-3 h-3" /> Book Token
      </Link>
    </div>
  );
}

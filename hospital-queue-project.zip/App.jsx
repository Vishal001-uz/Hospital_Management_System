import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './context/AuthContext';
import { initializeData } from './mockData';

import LoginPage       from './pages/LoginPage';
import PatientBooking  from './pages/PatientBooking';
import QueueStatus     from './pages/QueueStatus';
import DoctorDashboard from './pages/DoctorDashboard';
import AdminPanel      from './pages/AdminPanel';
import LiveDisplay     from './pages/LiveDisplay';

// Initialize localStorage seed data
initializeData();

// Protected route wrapper
const Protected = ({ children, role }) => {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (role && user.role !== role) return <Navigate to="/login" replace />;
  return children;
};

const AppRoutes = () => {
  const { user } = useAuth();

  return (
    <Routes>
      {/* Public routes */}
      <Route path="/login"   element={user ? <Navigate to={user.role === 'ADMIN' ? '/admin' : '/doctor'} /> : <LoginPage />} />
      <Route path="/book"    element={<PatientBooking />} />
      <Route path="/queue/:tokenId" element={<QueueStatus />} />
      <Route path="/live"    element={<LiveDisplay />} />
      <Route path="/live/:doctorId" element={<LiveDisplay />} />

      {/* Protected routes */}
      <Route path="/doctor" element={
        <Protected role="DOCTOR"><DoctorDashboard /></Protected>
      } />
      <Route path="/admin" element={
        <Protected role="ADMIN"><AdminPanel /></Protected>
      } />

      {/* Default redirect */}
      <Route path="/" element={
        user
          ? <Navigate to={user.role === 'ADMIN' ? '/admin' : '/doctor'} />
          : <Navigate to="/book" />
      } />
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
};

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: '#1a2236',
              color: '#e2e8f0',
              border: '1px solid rgba(255,255,255,0.1)',
              borderRadius: '12px',
              fontSize: '14px',
            },
            success: { iconTheme: { primary: '#22c55e', secondary: '#fff' } },
            error:   { iconTheme: { primary: '#ef4444', secondary: '#fff' } },
          }}
        />
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
}

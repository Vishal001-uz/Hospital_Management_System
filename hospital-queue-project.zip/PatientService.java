package com.hospital.queue.patient.service;

import com.hospital.queue.exception.ResourceNotFoundException;
import com.hospital.queue.patient.dto.PatientRequest;
import com.hospital.queue.patient.entity.Patient;
import com.hospital.queue.patient.repository.PatientRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class PatientService {

    private final PatientRepository patientRepository;

    public Patient createOrFind(PatientRequest request) {
        // If phone already exists, return existing patient
        return patientRepository.findByPhone(request.getPhone())
                .orElseGet(() -> {
                    Patient patient = Patient.builder()
                            .name(request.getName())
                            .phone(request.getPhone())
                            .age(request.getAge())
                            .build();
                    Patient saved = patientRepository.save(patient);
                    log.info("New patient registered: {} ({})", saved.getName(), saved.getPhone());
                    return saved;
                });
    }

    public Patient getById(Long id) {
        return patientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + id));
    }

    public List<Patient> getAll() {
        return patientRepository.findAll();
    }
}

package com.hospital.queue.analytics.controller;

import com.hospital.queue.doctor.entity.Doctor;
import com.hospital.queue.doctor.repository.DoctorRepository;
import com.hospital.queue.token.entity.Token;
import com.hospital.queue.token.enums.TokenStatus;
import com.hospital.queue.token.repository.TokenRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/analytics")
@RequiredArgsConstructor
@Tag(name = "Analytics", description = "Hospital analytics APIs")
public class AnalyticsController {

    private final TokenRepository tokenRepository;
    private final DoctorRepository doctorRepository;

    @GetMapping("/daily")
    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR')")
    @Operation(summary = "Get daily analytics for last 7 days")
    public ResponseEntity<Map<String, Object>> getDailyAnalytics() {
        LocalDate today = LocalDate.now();
        LocalDate weekAgo = today.minusDays(6);

        List<Token> weekTokens = tokenRepository.findByDateRange(weekAgo, today);
        List<Doctor> doctors = doctorRepository.findAll();

        // By day
        List<Map<String, Object>> byDay = new ArrayList<>();
        for (int i = 6; i >= 0; i--) {
            LocalDate date = today.minusDays(i);
            List<Token> dayTokens = weekTokens.stream()
                    .filter(t -> t.getTokenDate().equals(date)).toList();
            Map<String, Object> day = new LinkedHashMap<>();
            day.put("date", date.toString());
            day.put("label", date.getDayOfWeek().name().substring(0, 3) + " " + date.getDayOfMonth());
            day.put("total", dayTokens.size());
            day.put("completed", dayTokens.stream().filter(t -> t.getStatus() == TokenStatus.COMPLETED).count());
            day.put("cancelled", dayTokens.stream().filter(t -> t.getStatus() == TokenStatus.CANCELLED).count());
            day.put("waiting",   dayTokens.stream().filter(t -> t.getStatus() == TokenStatus.WAITING).count());
            byDay.add(day);
        }

        // By doctor
        List<Map<String, Object>> byDoctor = doctors.stream().map(doc -> {
            List<Token> docTokens = weekTokens.stream().filter(t -> t.getDoctor().getId().equals(doc.getId())).toList();
            List<Token> todayDoc  = docTokens.stream().filter(t -> t.getTokenDate().equals(today)).toList();
            long completed        = docTokens.stream().filter(t -> t.getStatus() == TokenStatus.COMPLETED).count();
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("doctor", doc.getName());
            row.put("department", doc.getDepartment());
            row.put("totalPatients", docTokens.size());
            row.put("todayPatients", todayDoc.size());
            row.put("completionRate", docTokens.isEmpty() ? 0 : Math.round((double) completed / docTokens.size() * 100));
            row.put("avgWaitMin", doc.getAvgConsultationTime());
            return row;
        }).collect(Collectors.toList());

        List<Token> todayAll = weekTokens.stream().filter(t -> t.getTokenDate().equals(today)).toList();

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("byDay", byDay);
        result.put("byDoctor", byDoctor);
        result.put("todayTotal", todayAll.size());
        result.put("todayCompleted", todayAll.stream().filter(t -> t.getStatus() == TokenStatus.COMPLETED).count());
        result.put("totalPatients", tokenRepository.count());
        result.put("generatedAt", today.toString());

        return ResponseEntity.ok(result);
    }
}

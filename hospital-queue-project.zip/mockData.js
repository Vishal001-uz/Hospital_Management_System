/**
 * mockData.js
 * Complete localStorage-based mock backend service.
 * Mirrors all Spring Boot REST API endpoints.
 * Replace these calls with real Axios HTTP calls when the backend is running.
 */

const KEYS = {
  USERS:    'hq_users',
  PATIENTS: 'hq_patients',
  DOCTORS:  'hq_doctors',
  TOKENS:   'hq_tokens',
};

// ─── Helpers ────────────────────────────────────────────────────────────────

const read  = (key) => JSON.parse(localStorage.getItem(key) || '[]');
const write = (key, data) => localStorage.setItem(key, JSON.stringify(data));
const nextId = (arr) => arr.length ? Math.max(...arr.map(x => x.id)) + 1 : 1;
const today  = () => new Date().toISOString().split('T')[0];
const delay  = (ms = 100) => new Promise(r => setTimeout(r, ms));

// ─── Seed Data ───────────────────────────────────────────────────────────────

export const initializeData = () => {
  if (!localStorage.getItem(KEYS.USERS)) {
    write(KEYS.USERS, [
      { id: 1, username: 'admin',      password: 'admin123',  role: 'ADMIN',  name: 'Admin User',        doctorId: null },
      { id: 2, username: 'dr.sharma',  password: 'doctor123', role: 'DOCTOR', name: 'Dr. Rajesh Sharma',  doctorId: 1 },
      { id: 3, username: 'dr.mehta',   password: 'doctor123', role: 'DOCTOR', name: 'Dr. Priya Mehta',    doctorId: 2 },
      { id: 4, username: 'dr.kapoor',  password: 'doctor123', role: 'DOCTOR', name: 'Dr. Anil Kapoor',    doctorId: 3 },
    ]);
  }

  if (!localStorage.getItem(KEYS.DOCTORS)) {
    write(KEYS.DOCTORS, [
      { id: 1, name: 'Dr. Rajesh Sharma',  department: 'Cardiology',      availableFrom: '09:00', availableTo: '17:00', avgConsultationTime: 10 },
      { id: 2, name: 'Dr. Priya Mehta',    department: 'Neurology',       availableFrom: '10:00', availableTo: '18:00', avgConsultationTime: 15 },
      { id: 3, name: 'Dr. Anil Kapoor',    department: 'Orthopedics',     availableFrom: '08:00', availableTo: '16:00', avgConsultationTime: 12 },
      { id: 4, name: 'Dr. Sunita Verma',   department: 'Pediatrics',      availableFrom: '09:00', availableTo: '15:00', avgConsultationTime: 8  },
      { id: 5, name: 'Dr. Vikram Singh',   department: 'Dermatology',     availableFrom: '11:00', availableTo: '19:00', avgConsultationTime: 10 },
    ]);
  }

  if (!localStorage.getItem(KEYS.PATIENTS)) {
    write(KEYS.PATIENTS, [
      { id: 1, name: 'Ramesh Kumar',    phone: '9876543210', age: 45, createdAt: new Date().toISOString() },
      { id: 2, name: 'Priya Sharma',    phone: '9876543211', age: 32, createdAt: new Date().toISOString() },
      { id: 3, name: 'Arun Patel',      phone: '9876543212', age: 51, createdAt: new Date().toISOString() },
      { id: 4, name: 'Deepa Nair',      phone: '9876543213', age: 28, createdAt: new Date().toISOString() },
      { id: 5, name: 'Suresh Reddy',    phone: '9876543214', age: 60, createdAt: new Date().toISOString() },
      { id: 6, name: 'Kavitha Menon',   phone: '9876543215', age: 38, createdAt: new Date().toISOString() },
      { id: 7, name: 'Rajesh Nair',     phone: '9876543216', age: 44, createdAt: new Date().toISOString() },
    ]);
  }

  if (!localStorage.getItem(KEYS.TOKENS)) {
    const d = today();
    write(KEYS.TOKENS, [
      { id: 1,  tokenNumber: 1, status: 'COMPLETED',   patientId: 1, doctorId: 1, date: d, createdAt: new Date(Date.now() - 120*60000).toISOString() },
      { id: 2,  tokenNumber: 2, status: 'COMPLETED',   patientId: 2, doctorId: 1, date: d, createdAt: new Date(Date.now() - 100*60000).toISOString() },
      { id: 3,  tokenNumber: 3, status: 'IN_PROGRESS', patientId: 3, doctorId: 1, date: d, createdAt: new Date(Date.now() - 80*60000).toISOString()  },
      { id: 4,  tokenNumber: 4, status: 'WAITING',     patientId: 4, doctorId: 1, date: d, createdAt: new Date(Date.now() - 60*60000).toISOString()  },
      { id: 5,  tokenNumber: 5, status: 'WAITING',     patientId: 5, doctorId: 1, date: d, createdAt: new Date(Date.now() - 40*60000).toISOString()  },
      { id: 6,  tokenNumber: 1, status: 'COMPLETED',   patientId: 6, doctorId: 2, date: d, createdAt: new Date(Date.now() - 200*60000).toISOString() },
      { id: 7,  tokenNumber: 2, status: 'IN_PROGRESS', patientId: 7, doctorId: 2, date: d, createdAt: new Date(Date.now() - 30*60000).toISOString()  },
      { id: 8,  tokenNumber: 3, status: 'WAITING',     patientId: 1, doctorId: 2, date: d, createdAt: new Date(Date.now() - 20*60000).toISOString()  },
      { id: 9,  tokenNumber: 1, status: 'IN_PROGRESS', patientId: 2, doctorId: 3, date: d, createdAt: new Date(Date.now() - 50*60000).toISOString()  },
      { id: 10, tokenNumber: 2, status: 'WAITING',     patientId: 3, doctorId: 3, date: d, createdAt: new Date(Date.now() - 10*60000).toISOString()  },
    ]);
  }
};

// ─── Enrichment ──────────────────────────────────────────────────────────────

const enrichToken = (token) => {
  const patients = read(KEYS.PATIENTS);
  const doctors  = read(KEYS.DOCTORS);
  return {
    ...token,
    patient: patients.find(p => p.id === token.patientId) || null,
    doctor:  doctors.find(d => d.id === token.doctorId)   || null,
  };
};

// ─── AUTH SERVICE ─────────────────────────────────────────────────────────────

export const authService = {
  login: async (username, password) => {
    await delay(300);
    const users = read(KEYS.USERS);
    const user = users.find(u => u.username === username && u.password === password);
    if (!user) throw new Error('Invalid username or password');
    const token = btoa(JSON.stringify({ userId: user.id, role: user.role, exp: Date.now() + 86400000 }));
    return { token, role: user.role, name: user.name, doctorId: user.doctorId, username: user.username };
  },

  register: async ({ username, password, role, name }) => {
    await delay(300);
    const users = read(KEYS.USERS);
    if (users.find(u => u.username === username)) throw new Error('Username already exists');
    const newUser = { id: nextId(users), username, password, role, name, doctorId: null };
    write(KEYS.USERS, [...users, newUser]);
    return { message: 'User registered successfully' };
  },
};

// ─── PATIENT SERVICE ──────────────────────────────────────────────────────────

export const patientService = {
  create: async ({ name, phone, age }) => {
    await delay(200);
    const patients = read(KEYS.PATIENTS);
    // Don't create duplicate for same phone
    const existing = patients.find(p => p.phone === phone);
    if (existing) return existing;
    const newPatient = { id: nextId(patients), name, phone, age: parseInt(age), createdAt: new Date().toISOString() };
    write(KEYS.PATIENTS, [...patients, newPatient]);
    return newPatient;
  },

  getById: async (id) => {
    await delay(100);
    const patients = read(KEYS.PATIENTS);
    const patient = patients.find(p => p.id === parseInt(id));
    if (!patient) throw new Error('Patient not found');
    return patient;
  },

  getAll: async () => {
    await delay(100);
    return read(KEYS.PATIENTS);
  },
};

// ─── DOCTOR SERVICE ───────────────────────────────────────────────────────────

export const doctorService = {
  getAll: async () => {
    await delay(100);
    return read(KEYS.DOCTORS);
  },

  getById: async (id) => {
    await delay(100);
    const doctors = read(KEYS.DOCTORS);
    return doctors.find(d => d.id === parseInt(id)) || null;
  },

  create: async ({ name, department, availableFrom, availableTo, avgConsultationTime }) => {
    await delay(300);
    const doctors = read(KEYS.DOCTORS);
    const users   = read(KEYS.USERS);
    const newDoc = {
      id: nextId(doctors), name, department,
      availableFrom, availableTo,
      avgConsultationTime: parseInt(avgConsultationTime) || 10,
    };
    write(KEYS.DOCTORS, [...doctors, newDoc]);
    // Also create a user account for the doctor
    const username = 'dr.' + name.split(' ').pop().toLowerCase().replace(/[^a-z]/g, '');
    const newUser = {
      id: nextId(users), username, password: 'doctor123',
      role: 'DOCTOR', name, doctorId: newDoc.id,
    };
    write(KEYS.USERS, [...users, newUser]);
    return { ...newDoc, loginUsername: username, loginPassword: 'doctor123' };
  },

  update: async (id, data) => {
    await delay(200);
    const doctors = read(KEYS.DOCTORS).map(d => d.id === parseInt(id) ? { ...d, ...data } : d);
    write(KEYS.DOCTORS, doctors);
    return doctors.find(d => d.id === parseInt(id));
  },

  delete: async (id) => {
    await delay(200);
    const doctors = read(KEYS.DOCTORS).filter(d => d.id !== parseInt(id));
    write(KEYS.DOCTORS, doctors);
    return { message: 'Doctor deleted' };
  },
};

// ─── TOKEN SERVICE ────────────────────────────────────────────────────────────

export const tokenService = {
  book: async ({ patientId, doctorId }) => {
    await delay(400);
    const tokens = read(KEYS.TOKENS);
    const d = today();

    // Check if patient already has an active token for this doctor today
    const hasActive = tokens.find(
      t => t.patientId === parseInt(patientId) &&
           t.doctorId  === parseInt(doctorId)  &&
           t.date === d &&
           ['WAITING', 'IN_PROGRESS'].includes(t.status)
    );
    if (hasActive) throw new Error('Patient already has an active token for this doctor today');

    // Auto-increment token number per doctor per day
    const todayTokens = tokens.filter(t => t.doctorId === parseInt(doctorId) && t.date === d);
    const maxNum = todayTokens.length ? Math.max(...todayTokens.map(t => t.tokenNumber)) : 0;

    const newToken = {
      id: nextId(tokens),
      tokenNumber: maxNum + 1,
      status: 'WAITING',
      patientId: parseInt(patientId),
      doctorId: parseInt(doctorId),
      date: d,
      createdAt: new Date().toISOString(),
    };
    write(KEYS.TOKENS, [...tokens, newToken]);

    // Simulate notification
    notificationService.send('TOKEN_BOOKED', enrichToken(newToken));

    return enrichToken(newToken);
  },

  getByDoctor: async (doctorId) => {
    await delay(150);
    const tokens = read(KEYS.TOKENS);
    return tokens
      .filter(t => t.doctorId === parseInt(doctorId) && t.date === today())
      .sort((a, b) => a.tokenNumber - b.tokenNumber)
      .map(enrichToken);
  },

  getByToken: async (tokenId) => {
    await delay(100);
    const tokens = read(KEYS.TOKENS);
    const token = tokens.find(t => t.id === parseInt(tokenId));
    if (!token) throw new Error('Token not found');
    return enrichToken(token);
  },

  nextPatient: async (doctorId) => {
    await delay(300);
    let tokens = read(KEYS.TOKENS);
    const d = today();

    // Mark current IN_PROGRESS as COMPLETED
    tokens = tokens.map(t => {
      if (t.doctorId === parseInt(doctorId) && t.date === d && t.status === 'IN_PROGRESS') {
        return { ...t, status: 'COMPLETED', completedAt: new Date().toISOString() };
      }
      return t;
    });

    // Find next WAITING
    const nextWaiting = tokens
      .filter(t => t.doctorId === parseInt(doctorId) && t.date === d && t.status === 'WAITING')
      .sort((a, b) => a.tokenNumber - b.tokenNumber)[0];

    if (!nextWaiting) {
      write(KEYS.TOKENS, tokens);
      return { message: 'No more waiting patients', currentToken: null };
    }

    tokens = tokens.map(t => t.id === nextWaiting.id ? { ...t, status: 'IN_PROGRESS' } : t);
    write(KEYS.TOKENS, tokens);

    const updatedToken = enrichToken(tokens.find(t => t.id === nextWaiting.id));
    notificationService.send('TURN_NOW', updatedToken);

    // Check if there are 3 or fewer waiting — alert next ones
    const stillWaiting = tokens
      .filter(t => t.doctorId === parseInt(doctorId) && t.date === d && t.status === 'WAITING')
      .sort((a, b) => a.tokenNumber - b.tokenNumber);

    if (stillWaiting.length > 0 && stillWaiting.length <= 3) {
      notificationService.send('TURN_APPROACHING', enrichToken(stillWaiting[0]));
    }

    return updatedToken;
  },

  cancel: async (tokenId) => {
    await delay(200);
    const tokens = read(KEYS.TOKENS).map(t =>
      t.id === parseInt(tokenId) ? { ...t, status: 'CANCELLED' } : t
    );
    write(KEYS.TOKENS, tokens);
    return tokens.find(t => t.id === parseInt(tokenId));
  },

  getEstimatedWait: (token, allTokens) => {
    if (token.status !== 'WAITING') return 0;
    const ahead = allTokens.filter(
      t => t.doctorId === token.doctorId &&
           t.date === token.date &&
           t.status === 'WAITING' &&
           t.tokenNumber < token.tokenNumber
    );
    const inProgress = allTokens.find(
      t => t.doctorId === token.doctorId && t.date === token.date && t.status === 'IN_PROGRESS'
    );
    const avgTime = token.doctor?.avgConsultationTime || 10;
    return (ahead.length + (inProgress ? 1 : 0)) * avgTime;
  },
};

// ─── QUEUE SERVICE ────────────────────────────────────────────────────────────

export const queueService = {
  getLive: async (doctorId) => {
    await delay(100);
    const tokens = read(KEYS.TOKENS);
    const d = today();
    const doctorTokens = tokens
      .filter(t => t.doctorId === parseInt(doctorId) && t.date === d)
      .sort((a, b) => a.tokenNumber - b.tokenNumber)
      .map(enrichToken);

    const current  = doctorTokens.find(t => t.status === 'IN_PROGRESS') || null;
    const waiting  = doctorTokens.filter(t => t.status === 'WAITING');
    const completed = doctorTokens.filter(t => t.status === 'COMPLETED').length;

    const avgTime = current?.doctor?.avgConsultationTime || 10;

    return {
      current,
      waiting,
      completed,
      totalToday: doctorTokens.length,
      nextTokens: waiting.slice(0, 3),
      avgWaitPerPatient: avgTime,
    };
  },

  getAllLive: async () => {
    await delay(150);
    const doctors = read(KEYS.DOCTORS);
    const results = [];
    for (const doc of doctors) {
      const q = await queueService.getLive(doc.id);
      results.push({ doctor: doc, ...q });
    }
    return results;
  },
};

// ─── ANALYTICS SERVICE ────────────────────────────────────────────────────────

export const analyticsService = {
  getDaily: async () => {
    await delay(200);
    const tokens  = read(KEYS.TOKENS);
    const doctors = read(KEYS.DOCTORS);

    // Last 7 days
    const days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - i);
      return d.toISOString().split('T')[0];
    }).reverse();

    const byDay = days.map(date => {
      const dayTokens = tokens.filter(t => t.date === date);
      return {
        date,
        label: new Date(date).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' }),
        total: dayTokens.length,
        completed: dayTokens.filter(t => t.status === 'COMPLETED').length,
        cancelled: dayTokens.filter(t => t.status === 'CANCELLED').length,
        waiting: dayTokens.filter(t => t.status === 'WAITING').length,
      };
    });

    const byDoctor = doctors.map(doc => {
      const docTokens = tokens.filter(t => t.doctorId === doc.id);
      const completedCount = docTokens.filter(t => t.status === 'COMPLETED').length;
      return {
        doctor: doc.name,
        department: doc.department,
        totalPatients: docTokens.length,
        todayPatients: docTokens.filter(t => t.date === today()).length,
        avgWaitMin: doc.avgConsultationTime * (completedCount > 0 ? completedCount / 2 : 1),
        completionRate: docTokens.length ? Math.round((completedCount / docTokens.length) * 100) : 0,
      };
    });

    const totalPatients = tokens.length;
    const todayTotal    = tokens.filter(t => t.date === today()).length;
    const todayCompleted = tokens.filter(t => t.date === today() && t.status === 'COMPLETED').length;

    return { byDay, byDoctor, totalPatients, todayTotal, todayCompleted };
  },
};

// ─── NOTIFICATION SERVICE ────────────────────────────────────────────────────

export const notificationService = {
  send: (event, token) => {
    const messages = {
      TOKEN_BOOKED:      `✅ Token #${token.tokenNumber} booked for ${token.patient?.name || 'Patient'} with ${token.doctor?.name}. Estimated wait: ~${tokenService.getEstimatedWait(token, read(KEYS.TOKENS).filter(t=>t.doctorId===token.doctorId && t.date===token.date).map(enrichToken))} min.`,
      TURN_APPROACHING:  `⚠️ ${token.patient?.name || 'Patient'}: Your turn is approaching! Token #${token.tokenNumber}. Please be ready.`,
      TURN_NOW:          `🔔 Token #${token.tokenNumber} — ${token.patient?.name || 'Patient'}, please proceed to the doctor's room now!`,
    };
    console.log('[NOTIFICATION]', event, messages[event] || '');
    // Store in notification log
    const log = JSON.parse(localStorage.getItem('hq_notifications') || '[]');
    log.unshift({ id: Date.now(), event, message: messages[event], time: new Date().toISOString() });
    localStorage.setItem('hq_notifications', JSON.stringify(log.slice(0, 50)));
  },

  getLogs: () => JSON.parse(localStorage.getItem('hq_notifications') || '[]'),
};

export default {
  auth: authService,
  patients: patientService,
  doctors: doctorService,
  tokens: tokenService,
  queue: queueService,
  analytics: analyticsService,
  notifications: notificationService,
};

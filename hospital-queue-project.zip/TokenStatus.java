package com.hospital.queue.token.enums;

public enum TokenStatus {
    WAITING,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED
}

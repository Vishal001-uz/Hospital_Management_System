package com.hospital.queue.queue.dto;

import com.hospital.queue.doctor.entity.Doctor;
import com.hospital.queue.token.entity.Token;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class QueueResponse {
    private Doctor doctor;
    private Token currentToken;
    private List<Token> waitingTokens;
    private int completedCount;
    private int totalToday;
    private int estimatedWaitForFirstMinutes;
    private double avgWaitPerPatientMinutes;
}

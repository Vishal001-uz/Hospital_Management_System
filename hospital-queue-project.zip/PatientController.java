package com.hospital.queue.patient.controller;

import com.hospital.queue.patient.dto.PatientRequest;
import com.hospital.queue.patient.entity.Patient;
import com.hospital.queue.patient.service.PatientService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/patients")
@RequiredArgsConstructor
@Tag(name = "Patients", description = "Patient management APIs")
public class PatientController {

    private final PatientService patientService;

    @PostMapping
    @Operation(summary = "Register a new patient (or retrieve existing by phone)")
    public ResponseEntity<Patient> createOrFind(@Valid @RequestBody PatientRequest request) {
        return ResponseEntity.ok(patientService.createOrFind(request));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get patient by ID")
    public ResponseEntity<Patient> getById(@PathVariable Long id) {
        return ResponseEntity.ok(patientService.getById(id));
    }

    @GetMapping
    @Operation(summary = "Get all patients")
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(patientService.getAll());
    }
}

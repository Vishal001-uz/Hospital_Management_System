import { useState, useEffect, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { tokenService, queueService } from '../mockData';
import QRCode from 'qrcode';
import {
  Activity, Clock, Users, CheckCircle, XCircle, AlertCircle,
  RefreshCw, ArrowLeft, Ticket, Stethoscope, Bell
} from 'lucide-react';

const STATUS_CONFIG = {
  WAITING:     { label: 'Waiting',     icon: Clock,       color: '#f59e0b', bg: 'rgba(245,158,11,0.12)',   border: 'rgba(245,158,11,0.3)',  badge: 'badge-waiting'     },
  IN_PROGRESS: { label: 'Your Turn!',  icon: AlertCircle, color: '#3b82f6', bg: 'rgba(59,130,246,0.12)',   border: 'rgba(59,130,246,0.35)', badge: 'badge-in-progress' },
  COMPLETED:   { label: 'Completed',   icon: CheckCircle, color: '#22c55e', bg: 'rgba(34,197,94,0.12)',    border: 'rgba(34,197,94,0.3)',   badge: 'badge-completed'   },
  CANCELLED:   { label: 'Cancelled',   icon: XCircle,     color: '#ef4444', bg: 'rgba(239,68,68,0.12)',    border: 'rgba(239,68,68,0.3)',   badge: 'badge-cancelled'   },
};

export default function QueueStatus() {
  const { tokenId }   = useParams();
  const qrRef         = useRef(null);

  const [token, setToken]   = useState(null);
  const [queue, setQueue]   = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState('');
  const [qrDataUrl, setQrDataUrl] = useState('');
  const [lastRefresh, setLastRefresh] = useState(new Date());

  const fetchData = async () => {
    try {
      const t = await tokenService.getByToken(tokenId);
      setToken(t);
      setError('');
      if (t.doctorId) {
        const q = await queueService.getLive(t.doctorId);
        setQueue(q);
      }
      setLastRefresh(new Date());
    } catch (err) {
      setError(err.message || 'Token not found');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 5000); // poll every 5s
    return () => clearInterval(interval);
  }, [tokenId]);

  useEffect(() => {
    if (token) {
      const qrData = JSON.stringify({ tokenId: token.id, tokenNumber: token.tokenNumber, doctorId: token.doctorId });
      QRCode.toDataURL(qrData, {
        width: 180, margin: 1,
        color: { dark: '#ffffff', light: '#00000000' },
      }).then(setQrDataUrl);
    }
  }, [token?.id]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{background:'#080b14'}}>
        <div className="text-center">
          <div className="spinner w-10 h-10 mx-auto mb-4" style={{width:'40px',height:'40px',borderWidth:'3px'}} />
          <p className="text-slate-400">Loading token status...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4" style={{background:'#080b14'}}>
        <div className="glass-card p-8 text-center max-w-sm w-full">
          <XCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
          <h2 className="text-lg font-semibold text-white mb-2">Token Not Found</h2>
          <p className="text-slate-400 text-sm mb-6">{error}</p>
          <Link to="/book" className="btn-primary w-full">Book a New Token</Link>
        </div>
      </div>
    );
  }

  const cfg        = STATUS_CONFIG[token.status] || STATUS_CONFIG.WAITING;
  const StatusIcon = cfg.icon;
  const ahead      = queue?.waiting.filter(t => t.tokenNumber < token.tokenNumber).length ?? 0;
  const estWait    = ahead * (token.doctor?.avgConsultationTime || 10);
  const isYourTurn = token.status === 'IN_PROGRESS';

  return (
    <div className="min-h-screen" style={{background:'#080b14'}}>
      {/* Nav */}
      <nav className="flex items-center justify-between px-6 py-4" style={{borderBottom:'1px solid rgba(255,255,255,0.06)'}}>
        <div className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-primary-400" />
          <span className="font-bold text-white">MediQueue</span>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={fetchData} className="btn-secondary text-xs px-3 py-2 gap-1.5">
            <RefreshCw className="w-3.5 h-3.5" /> Refresh
          </button>
          <Link to="/book" className="text-slate-400 text-xs hover:text-white transition-colors flex items-center gap-1">
            <ArrowLeft className="w-3.5 h-3.5" /> Book Another
          </Link>
        </div>
      </nav>

      {/* YOUR TURN alert banner */}
      {isYourTurn && (
        <div className="text-center py-4 animate-pulse-slow"
             style={{background:'linear-gradient(90deg, rgba(59,130,246,0.2), rgba(34,211,238,0.2), rgba(59,130,246,0.2))'}}>
          <div className="flex items-center justify-center gap-2 text-cyan-300 font-bold text-lg">
            <Bell className="w-5 h-5" /> Please proceed to the doctor's room now!
          </div>
        </div>
      )}

      <div className="max-w-lg mx-auto px-4 py-8 space-y-6">
        {/* Token status card */}
        <div className="glass-card p-6 animate-slide-up" style={{borderColor: cfg.border}}>
          <div className="flex items-start justify-between mb-6">
            <div>
              <p className="text-xs text-slate-400 mb-1">Your Token</p>
              <div className="text-6xl font-black gradient-text">#{token.tokenNumber}</div>
            </div>
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${isYourTurn ? 'animate-pulse-slow' : ''}`}
                 style={{background: cfg.bg, border: `1px solid ${cfg.border}`}}>
              <StatusIcon className="w-7 h-7" style={{color: cfg.color}} />
            </div>
          </div>

          <div className="rounded-xl px-4 py-3 flex items-center justify-between"
               style={{background: cfg.bg, border: `1px solid ${cfg.border}`}}>
            <span className="font-semibold text-sm" style={{color: cfg.color}}>{cfg.label}</span>
            <span className="text-xs text-slate-400">Last updated: {lastRefresh.toLocaleTimeString()}</span>
          </div>
        </div>

        {/* Info grid */}
        <div className="grid grid-cols-2 gap-4">
          {[
            { icon: Stethoscope, label: 'Doctor',     value: token.doctor?.name || '—'   },
            { icon: Users,       label: 'Department',  value: token.doctor?.department || '—' },
            { icon: Users,       label: 'Ahead of You', value: token.status === 'WAITING' ? `${ahead} patient${ahead !== 1 ? 's' : ''}` : '—'  },
            { icon: Clock,       label: 'Est. Wait',   value: token.status === 'WAITING' ? `~${estWait} min` : token.status === 'IN_PROGRESS' ? 'Now!' : '—' },
          ].map(({ icon: Icon, label, value }) => (
            <div key={label} className="glass-card p-4">
              <div className="flex items-center gap-2 mb-1">
                <Icon className="w-3.5 h-3.5 text-slate-500" />
                <span className="text-xs text-slate-500">{label}</span>
              </div>
              <div className="text-sm font-semibold text-white">{value}</div>
            </div>
          ))}
        </div>

        {/* Patient info */}
        <div className="glass-card p-5">
          <h3 className="text-sm font-semibold text-white mb-4">Patient Details</h3>
          <div className="space-y-2">
            {[
              { label: 'Name',  value: token.patient?.name },
              { label: 'Phone', value: token.patient?.phone },
              { label: 'Age',   value: `${token.patient?.age} years` },
            ].map(({ label, value }) => (
              <div key={label} className="flex justify-between text-sm" style={{borderBottom:'1px solid rgba(255,255,255,0.04)', paddingBottom:'8px'}}>
                <span className="text-slate-400">{label}</span>
                <span className="text-white font-medium">{value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Queue peek */}
        {queue && queue.waiting.length > 0 && token.status === 'WAITING' && (
          <div className="glass-card p-5">
            <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
              <Users className="w-4 h-4 text-slate-400" /> Queue Position
            </h3>
            <div className="space-y-2">
              {queue.waiting.slice(0, 5).map((t, i) => (
                <div key={t.id}
                     className={`flex items-center justify-between px-3 py-2 rounded-lg ${t.id === token.id ? 'text-primary-300' : 'text-slate-400'}`}
                     style={{background: t.id === token.id ? 'rgba(59,130,246,0.15)' : 'rgba(255,255,255,0.02)', border: t.id === token.id ? '1px solid rgba(59,130,246,0.25)' : '1px solid transparent'}}>
                  <span className="text-xs font-medium">
                    {t.id === token.id ? '👉 You' : `#${i+1}`}
                  </span>
                  <span className="text-sm font-bold">Token #{t.tokenNumber}</span>
                  <span className="text-xs">~{i * (token.doctor?.avgConsultationTime || 10)} min</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* QR code */}
        {qrDataUrl && (
          <div className="glass-card p-6 text-center">
            <p className="text-xs text-slate-400 mb-4 flex items-center justify-center gap-1">
              <Ticket className="w-3.5 h-3.5" /> Show this QR at hospital counter
            </p>
            <img src={qrDataUrl} alt="Token QR Code" className="w-40 h-40 mx-auto rounded-xl"
                 style={{background:'rgba(255,255,255,0.05)', padding:'8px'}} />
            <p className="text-xs text-slate-500 mt-3">Token #{token.tokenNumber} • {token.doctor?.name}</p>
          </div>
        )}

        <p className="text-center text-xs text-slate-600">Auto-refreshes every 5 seconds</p>
      </div>
    </div>
  );
}

package com.hospital.queue.doctor.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class DoctorRequest {
    @NotBlank(message = "Doctor name is required")
    private String name;

    @NotBlank(message = "Department is required")
    private String department;

    @Pattern(regexp = "([01]?[0-9]|2[0-3]):[0-5][0-9]", message = "Time format should be HH:mm")
    private String availableFrom;

    @Pattern(regexp = "([01]?[0-9]|2[0-3]):[0-5][0-9]", message = "Time format should be HH:mm")
    private String availableTo;

    @Min(value = 5, message = "Min consultation time is 5 minutes")
    @Max(value = 60, message = "Max consultation time is 60 minutes")
    private int avgConsultationTime = 10;
}

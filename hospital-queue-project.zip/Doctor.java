package com.hospital.queue.doctor.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "doctors")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Doctor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(nullable = false, length = 100)
    private String department;

    @Column(name = "available_from", length = 5)
    private String availableFrom;

    @Column(name = "available_to", length = 5)
    private String availableTo;

    @Column(name = "avg_consultation_time")
    private int avgConsultationTime = 10; // minutes
}

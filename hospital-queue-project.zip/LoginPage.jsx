import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import { Activity, Lock, User, Eye, EyeOff, Stethoscope } from 'lucide-react';

export default function LoginPage() {
  const { login } = useAuth();
  const navigate  = useNavigate();

  const [form, setForm]       = useState({ username: '', password: '' });
  const [showPwd, setShowPwd] = useState(false);
  const [loading, setLoading] = useState(false);

  const quickFill = (username, password) => setForm({ username, password });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.username || !form.password) {
      toast.error('Please enter username and password');
      return;
    }
    setLoading(true);
    try {
      const session = await login(form.username, form.password);
      toast.success(`Welcome, ${session.name}!`);
      navigate(session.role === 'ADMIN' ? '/admin' : '/doctor', { replace: true });
    } catch (err) {
      toast.error(err.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const QUICK_LOGINS = [
    { label: 'Admin',     username: 'admin',      password: 'admin123',  color: 'from-violet-600 to-purple-600' },
    { label: 'Dr. Sharma (Cardiology)', username: 'dr.sharma', password: 'doctor123', color: 'from-blue-600 to-cyan-600' },
    { label: 'Dr. Mehta (Neurology)',   username: 'dr.mehta',  password: 'doctor123', color: 'from-teal-600 to-emerald-600' },
  ];

  return (
    <div className="min-h-screen bg-grid flex items-center justify-center px-4" style={{background:'radial-gradient(ellipse at 10% 20%, rgba(59,130,246,0.08) 0%, transparent 60%), radial-gradient(ellipse at 90% 80%, rgba(139,92,246,0.08) 0%, transparent 60%), #080b14'}}>
      
      {/* Background orbs */}
      <div className="fixed top-0 left-1/4 w-96 h-96 rounded-full opacity-10 blur-3xl" style={{background:'radial-gradient(circle, #3b82f6, transparent)'}} />
      <div className="fixed bottom-0 right-1/4 w-96 h-96 rounded-full opacity-10 blur-3xl" style={{background:'radial-gradient(circle, #8b5cf6, transparent)'}} />

      <div className="w-full max-w-md animate-fade-in">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-4 glow-blue"
               style={{background:'linear-gradient(135deg, #1e40af, #3b82f6)'}}>
            <Activity className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white">MediQueue</h1>
          <p className="text-slate-400 text-sm mt-1">Hospital Token Management System</p>
        </div>

        {/* Login card */}
        <div className="glass-card p-8">
          <div className="flex items-center gap-2 mb-6">
            <Lock className="w-5 h-5 text-primary-400" />
            <h2 className="text-lg font-semibold text-white">Staff Login</h2>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-2">Username</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  id="login-username"
                  type="text"
                  value={form.username}
                  onChange={e => setForm(f => ({ ...f, username: e.target.value }))}
                  placeholder="Enter username"
                  className="input-field pl-10"
                  autoComplete="username"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-400 mb-2">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  id="login-password"
                  type={showPwd ? 'text' : 'password'}
                  value={form.password}
                  onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                  placeholder="Enter password"
                  className="input-field pl-10 pr-10"
                  autoComplete="current-password"
                />
                <button type="button" onClick={() => setShowPwd(!showPwd)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors">
                  {showPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button id="login-submit" type="submit" disabled={loading} className="btn-primary w-full mt-2">
              {loading ? <span className="spinner" /> : <Lock className="w-4 h-4" />}
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>

          {/* Quick login buttons */}
          <div className="mt-6">
            <p className="text-xs text-slate-500 text-center mb-3">Quick Login (Demo)</p>
            <div className="flex flex-col gap-2">
              {QUICK_LOGINS.map(q => (
                <button key={q.username} onClick={() => quickFill(q.username, q.password)}
                        className="w-full py-2 px-4 rounded-lg text-xs font-medium text-white transition-all duration-200 hover:opacity-90 hover:scale-[1.01]"
                        style={{background:`linear-gradient(135deg, var(--tw-gradient-from), var(--tw-gradient-to))`,backgroundImage:`linear-gradient(135deg, ${q.color.includes('violet') ? '#7c3aed,#9333ea' : q.color.includes('teal') ? '#0d9488,#059669' : '#2563eb,#0891b2'})`}}>
                  {q.label}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-6 pt-5 border-t border-white/5 text-center">
            <p className="text-xs text-slate-500">Not staff?</p>
            <Link to="/book" className="text-primary-400 hover:text-primary-300 text-sm font-medium mt-1 inline-block transition-colors">
              Book a Token as Patient →
            </Link>
          </div>
          <div className="text-center mt-2">
            <Link to="/live" className="text-slate-500 hover:text-slate-300 text-xs transition-colors">
              View Live Queue Display
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

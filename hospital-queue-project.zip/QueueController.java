package com.hospital.queue.queue.controller;

import com.hospital.queue.doctor.entity.Doctor;
import com.hospital.queue.doctor.repository.DoctorRepository;
import com.hospital.queue.exception.ResourceNotFoundException;
import com.hospital.queue.queue.dto.QueueResponse;
import com.hospital.queue.token.entity.Token;
import com.hospital.queue.token.enums.TokenStatus;
import com.hospital.queue.token.repository.TokenRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/queue")
@RequiredArgsConstructor
@Tag(name = "Queue", description = "Live queue status APIs")
public class QueueController {

    private final TokenRepository tokenRepository;
    private final DoctorRepository doctorRepository;

    @GetMapping("/live/{doctorId}")
    @Operation(summary = "Get live queue status for a doctor")
    public ResponseEntity<QueueResponse> getLiveQueue(@PathVariable Long doctorId) {
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found"));

        LocalDate today = LocalDate.now();
        List<Token> allTokens = tokenRepository.findByDoctorIdAndTokenDateOrderByTokenNumberAsc(doctorId, today);

        Token current  = allTokens.stream().filter(t -> t.getStatus() == TokenStatus.IN_PROGRESS).findFirst().orElse(null);
        List<Token> waiting   = allTokens.stream().filter(t -> t.getStatus() == TokenStatus.WAITING).collect(Collectors.toList());
        long completedCount   = allTokens.stream().filter(t -> t.getStatus() == TokenStatus.COMPLETED).count();

        QueueResponse response = QueueResponse.builder()
                .doctor(doctor)
                .currentToken(current)
                .waitingTokens(waiting)
                .completedCount((int) completedCount)
                .totalToday(allTokens.size())
                .estimatedWaitForFirstMinutes(waiting.isEmpty() ? 0 : doctor.getAvgConsultationTime())
                .avgWaitPerPatientMinutes(doctor.getAvgConsultationTime())
                .build();

        return ResponseEntity.ok(response);
    }

    @GetMapping("/live")
    @Operation(summary = "Get live queue status for all doctors")
    public ResponseEntity<List<QueueResponse>> getAllLiveQueues() {
        List<Doctor> doctors = doctorRepository.findAll();
        LocalDate today = LocalDate.now();

        List<QueueResponse> responses = doctors.stream().map(doctor -> {
            List<Token> allTokens = tokenRepository.findByDoctorIdAndTokenDateOrderByTokenNumberAsc(doctor.getId(), today);
            Token current = allTokens.stream().filter(t -> t.getStatus() == TokenStatus.IN_PROGRESS).findFirst().orElse(null);
            List<Token> waiting = allTokens.stream().filter(t -> t.getStatus() == TokenStatus.WAITING).collect(Collectors.toList());
            long completedCount = allTokens.stream().filter(t -> t.getStatus() == TokenStatus.COMPLETED).count();
            return QueueResponse.builder()
                    .doctor(doctor).currentToken(current).waitingTokens(waiting)
                    .completedCount((int) completedCount).totalToday(allTokens.size())
                    .avgWaitPerPatientMinutes(doctor.getAvgConsultationTime())
                    .build();
        }).collect(Collectors.toList());

        return ResponseEntity.ok(responses);
    }
}

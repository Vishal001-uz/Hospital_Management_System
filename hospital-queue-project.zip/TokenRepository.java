package com.hospital.queue.token.repository;

import com.hospital.queue.token.entity.Token;
import com.hospital.queue.token.enums.TokenStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface TokenRepository extends JpaRepository<Token, Long> {

    /** Max token number for a doctor on a given date (for auto-increment) */
    @Query("SELECT COALESCE(MAX(t.tokenNumber), 0) FROM Token t WHERE t.doctor.id = :doctorId AND t.tokenDate = :date")
    int findMaxTokenNumberByDoctorAndDate(@Param("doctorId") Long doctorId, @Param("date") LocalDate date);

    /** All tokens for a doctor on a given date, sorted */
    List<Token> findByDoctorIdAndTokenDateOrderByTokenNumberAsc(Long doctorId, LocalDate tokenDate);

    /** Check if patient already has an active token for doctor today */
    @Query("SELECT t FROM Token t WHERE t.patient.id = :patientId AND t.doctor.id = :doctorId AND t.tokenDate = :date AND t.status IN ('WAITING','IN_PROGRESS')")
    Optional<Token> findActiveTokenForPatientAndDoctor(
            @Param("patientId") Long patientId,
            @Param("doctorId") Long doctorId,
            @Param("date") LocalDate date);

    /** First WAITING token for a doctor today */
    @Query("SELECT t FROM Token t WHERE t.doctor.id = :doctorId AND t.tokenDate = :date AND t.status = 'WAITING' ORDER BY t.tokenNumber ASC LIMIT 1")
    Optional<Token> findFirstWaitingByDoctorAndDate(@Param("doctorId") Long doctorId, @Param("date") LocalDate date);

    /** Current IN_PROGRESS token for a doctor */
    @Query("SELECT t FROM Token t WHERE t.doctor.id = :doctorId AND t.tokenDate = :date AND t.status = 'IN_PROGRESS'")
    Optional<Token> findInProgressByDoctorAndDate(@Param("doctorId") Long doctorId, @Param("date") LocalDate date);

    /** Count completed tokens */
    long countByDoctorIdAndTokenDateAndStatus(Long doctorId, LocalDate tokenDate, TokenStatus status);

    /** All tokens for analytics */
    @Query("SELECT t FROM Token t WHERE t.tokenDate BETWEEN :from AND :to")
    List<Token> findByDateRange(@Param("from") LocalDate from, @Param("to") LocalDate to);
}

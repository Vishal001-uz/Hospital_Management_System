package com.hospital.queue.notification.service;

import com.hospital.queue.token.entity.Token;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * Notification Service
 *
 * Currently uses console logging (mock).
 * To enable real SMS via Twilio, set notification.use-mock=false
 * and fill in twilio.* properties in application.properties.
 *
 * Twilio SDK can be added by including com.twilio.sdk:twilio dependency in pom.xml
 * and initializing: Twilio.init(accountSid, authToken)
 */
@Slf4j
@Service
public class NotificationService {

    @Value("${notification.use-mock:true}")
    private boolean useMock;

    @Value("${twilio.account-sid:}")
    private String twilioAccountSid;

    @Value("${twilio.auth-token:}")
    private String twilioAuthToken;

    @Value("${twilio.phone-number:}")
    private String twilioPhone;

    @Async
    public void sendBookingConfirmation(Token token) {
        String message = String.format(
                "✅ Token #%d booked! You are with Dr. %s (%s). " +
                "Current queue: %d patients ahead.",
                token.getTokenNumber(),
                token.getDoctor().getName(),
                token.getDoctor().getDepartment(),
                token.getTokenNumber() - 1
        );
        send(token.getPatient().getPhone(), message);
    }

    @Async
    public void notifyTurnApproaching(Token token) {
        String message = String.format(
                "⚠️ Alert! Token #%d — %s, your turn is approaching. Please be ready at Dr. %s's clinic.",
                token.getTokenNumber(),
                token.getPatient().getName(),
                token.getDoctor().getName()
        );
        send(token.getPatient().getPhone(), message);
    }

    @Async
    public void notifyTurnNow(Token token) {
        String message = String.format(
                "🔔 Token #%d — %s, it is YOUR TURN now! Please proceed to Dr. %s's room immediately.",
                token.getTokenNumber(),
                token.getPatient().getName(),
                token.getDoctor().getName()
        );
        send(token.getPatient().getPhone(), message);
    }

    private void send(String phoneNumber, String message) {
        if (useMock) {
            // Mock: log to console
            log.info("📱 [NOTIFICATION MOCK] To: +91{} | Msg: {}", phoneNumber, message);
        } else {
            // Twilio integration (uncomment when credentials are set)
            // try {
            //     Twilio.init(twilioAccountSid, twilioAuthToken);
            //     Message.creator(
            //         new PhoneNumber("+91" + phoneNumber),
            //         new PhoneNumber(twilioPhone),
            //         message
            //     ).create();
            //     log.info("SMS sent to {}", phoneNumber);
            // } catch (Exception e) {
            //     log.error("Failed to send SMS to {}: {}", phoneNumber, e.getMessage());
            // }
            log.warn("Twilio SMS disabled. Set notification.use-mock=false and add Twilio SDK to enable.");
        }
    }
}

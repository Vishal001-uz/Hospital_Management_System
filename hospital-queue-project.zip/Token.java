package com.hospital.queue.token.entity;

import com.hospital.queue.doctor.entity.Doctor;
import com.hospital.queue.patient.entity.Patient;
import com.hospital.queue.token.enums.TokenStatus;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(
    name = "tokens",
    indexes = {
        @Index(name = "idx_token_doctor_id", columnList = "doctor_id"),
        @Index(name = "idx_token_date", columnList = "token_date")
    },
    uniqueConstraints = {
        @UniqueConstraint(
            name = "uq_patient_doctor_date",
            columnNames = {"patient_id", "doctor_id", "token_date"}
        )
    }
)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Token {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "token_number", nullable = false)
    private int tokenNumber;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 15)
    private TokenStatus status;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "patient_id", nullable = false)
    private Patient patient;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "doctor_id", nullable = false)
    private Doctor doctor;

    @Column(name = "token_date", nullable = false)
    private LocalDate tokenDate;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "completed_at")
    private LocalDateTime completedAt;
}

package com.hospital.queue.auth.service;

import com.hospital.queue.auth.dto.AuthResponse;
import com.hospital.queue.auth.dto.LoginRequest;
import com.hospital.queue.auth.dto.RegisterRequest;
import com.hospital.queue.auth.entity.User;
import com.hospital.queue.auth.repository.UserRepository;
import com.hospital.queue.jwt.JwtUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    public AuthResponse register(RegisterRequest request) {
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new IllegalArgumentException("Username already exists: " + request.getUsername());
        }
        User user = User.builder()
                .username(request.getUsername())
                .password(passwordEncoder.encode(request.getPassword()))
                .name(request.getName())
                .role(request.getRole())
                .doctorId(request.getDoctorId())
                .build();
        userRepository.save(user);
        log.info("New user registered: {} [{}]", user.getUsername(), user.getRole());
        String token = jwtUtil.generateToken(user.getUsername(), user.getRole().name());
        return AuthResponse.builder()
                .token(token).role(user.getRole().name())
                .name(user.getName()).username(user.getUsername())
                .doctorId(user.getDoctorId())
                .build();
    }

    public AuthResponse login(LoginRequest request) {
        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new BadCredentialsException("Invalid username or password"));
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new BadCredentialsException("Invalid username or password");
        }
        log.info("User logged in: {} [{}]", user.getUsername(), user.getRole());
        String token = jwtUtil.generateToken(user.getUsername(), user.getRole().name());
        return AuthResponse.builder()
                .token(token).role(user.getRole().name())
                .name(user.getName()).username(user.getUsername())
                .doctorId(user.getDoctorId())
                .build();
    }
}

import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { doctorService, analyticsService, queueService } from '../mockData';
import toast from 'react-hot-toast';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell
} from 'recharts';
import {
  Activity, LogOut, Plus, X, Users, Stethoscope, TrendingUp,
  Clock, CheckCircle, Monitor, BarChart2, AlertCircle, ChevronDown
} from 'lucide-react';

const TABS = ['Overview', 'Doctors', 'Analytics', 'All Queues'];
const DEPT_COLORS_BG = {
  Cardiology: '#dc2626', Neurology: '#7c3aed', Orthopedics: '#d97706',
  Pediatrics: '#059669', Dermatology: '#2563eb', General: '#0891b2',
};

export default function AdminPanel() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const [tab, setTab]         = useState('Overview');
  const [doctors, setDoctors] = useState([]);
  const [analytics, setAnalytics] = useState(null);
  const [allQueues, setAllQueues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddDoctor, setShowAddDoctor] = useState(false);
  const [addingDoctor, setAddingDoctor]   = useState(false);
  const [newDoc, setNewDoc] = useState({
    name: '', department: '', availableFrom: '09:00', availableTo: '17:00', avgConsultationTime: '10'
  });

  const loadData = async () => {
    try {
      const [docs, analytics, queues] = await Promise.all([
        doctorService.getAll(),
        analyticsService.getDaily(),
        queueService.getAllLive(),
      ]);
      setDoctors(docs);
      setAnalytics(analytics);
      setAllQueues(queues);
    } catch (err) {
      toast.error('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleAddDoctor = async (e) => {
    e.preventDefault();
    if (!newDoc.name.trim() || !newDoc.department.trim()) {
      toast.error('Name and department are required');
      return;
    }
    setAddingDoctor(true);
    try {
      const result = await doctorService.create(newDoc);
      toast.success(`${result.name} added! Login: ${result.loginUsername} / ${result.loginPassword}`);
      setShowAddDoctor(false);
      setNewDoc({ name: '', department: '', availableFrom: '09:00', availableTo: '17:00', avgConsultationTime: '10' });
      loadData();
    } catch (err) {
      toast.error(err.message || 'Failed to add doctor');
    } finally {
      setAddingDoctor(false);
    }
  };

  const handleDeleteDoctor = async (id, name) => {
    if (!window.confirm(`Remove Dr. ${name}?`)) return;
    await doctorService.delete(id);
    toast.success('Doctor removed');
    loadData();
  };

  const handleLogout = () => { logout(); navigate('/login'); };

  const stats = analytics ? [
    { label: "Today's Patients", value: analytics.todayTotal,    icon: Users,       color: '#3b82f6' },
    { label: 'Completed Today',  value: analytics.todayCompleted, icon: CheckCircle, color: '#22c55e' },
    { label: 'Total Doctors',    value: doctors.length,           icon: Stethoscope, color: '#8b5cf6' },
    { label: 'Total Records',    value: analytics.totalPatients,  icon: TrendingUp,  color: '#f59e0b' },
  ] : [];

  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload || !payload.length) return null;
    return (
      <div className="glass-card px-4 py-3 text-xs">
        <p className="text-white font-semibold mb-1">{label}</p>
        {payload.map(p => (
          <p key={p.name} style={{color: p.color}}>{p.name}: {p.value}</p>
        ))}
      </div>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{background:'#080b14'}}>
        <div className="text-center">
          <div className="spinner w-10 h-10 mx-auto mb-4" style={{width:'40px',height:'40px',borderWidth:'3px'}} />
          <p className="text-slate-400">Loading admin panel...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col" style={{background:'#080b14'}}>
      {/* Nav */}
      <nav className="flex items-center justify-between px-6 py-4"
           style={{borderBottom:'1px solid rgba(255,255,255,0.07)', background:'rgba(13,18,32,0.95)', backdropFilter:'blur(12px)', position:'sticky', top:0, zIndex:40}}>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center"
               style={{background:'linear-gradient(135deg,#5b21b6,#7c3aed)'}}>
            <Activity className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="text-sm font-bold text-white">MediQueue Admin</div>
            <div className="text-xs text-slate-500">{user?.name}</div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Link to="/live" target="_blank" className="btn-secondary text-xs px-3 py-2 gap-1.5">
            <Monitor className="w-3.5 h-3.5" /> Live Display
          </Link>
          <button onClick={() => setShowAddDoctor(true)} className="btn-primary text-xs px-4 py-2">
            <Plus className="w-3.5 h-3.5" /> Add Doctor
          </button>
          <button onClick={handleLogout} className="btn-secondary text-xs px-3 py-2 text-red-400">
            <LogOut className="w-3.5 h-3.5" />
          </button>
        </div>
      </nav>

      {/* Tab bar */}
      <div className="px-6 py-0" style={{borderBottom:'1px solid rgba(255,255,255,0.06)', background:'rgba(13,18,32,0.7)'}}>
        <div className="flex gap-1 max-w-6xl mx-auto">
          {TABS.map(t => (
            <button key={t} onClick={() => setTab(t)}
                    className={`px-5 py-3.5 text-sm font-medium transition-all duration-200 border-b-2 ${
                      tab === t ? 'text-primary-400 border-primary-500' : 'text-slate-500 border-transparent hover:text-slate-300'
                    }`}>
              {t}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 p-6 max-w-6xl mx-auto w-full">

        {/* ─── OVERVIEW ─── */}
        {tab === 'Overview' && (
          <div className="animate-fade-in">
            <div className="page-header">
              <h1 className="page-title">System Overview</h1>
              <p className="page-subtitle">Hospital queue management at a glance</p>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              {stats.map(({ label, value, icon: Icon, color }) => (
                <div key={label} className="stat-card">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs text-slate-500">{label}</span>
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{background:`${color}18`}}>
                      <Icon className="w-4.5 h-4.5 w-5" style={{color}} />
                    </div>
                  </div>
                  <div className="text-3xl font-bold text-white">{value}</div>
                </div>
              ))}
            </div>

            {/* Active queues summary */}
            <div className="glass-card overflow-hidden mb-6">
              <div className="px-6 py-4" style={{borderBottom:'1px solid rgba(255,255,255,0.06)'}}>
                <h2 className="text-sm font-semibold text-white">Live Queue Summary</h2>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 p-6">
                {allQueues.map(q => (
                  <div key={q.doctor.id} className="rounded-xl p-4"
                       style={{background:'rgba(255,255,255,0.03)', border:'1px solid rgba(255,255,255,0.07)'}}>
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <div className="text-sm font-semibold text-white">{q.doctor.name}</div>
                        <div className="text-xs text-slate-500">{q.doctor.department}</div>
                      </div>
                      <div className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold text-white"
                           style={{background: DEPT_COLORS_BG[q.doctor.department] || '#2563eb'}}>
                        {q.doctor.department.charAt(0)}
                      </div>
                    </div>
                    <div className="flex gap-4">
                      <div>
                        <div className="text-lg font-bold text-amber-400">{q.waiting.length}</div>
                        <div className="text-xs text-slate-500">waiting</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-green-400">{q.completed}</div>
                        <div className="text-xs text-slate-500">done</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-blue-400">{q.current ? `#${q.current.tokenNumber}` : '—'}</div>
                        <div className="text-xs text-slate-500">serving</div>
                      </div>
                    </div>
                    <div className="mt-3">
                      <Link to={`/live/${q.doctor.id}`} target="_blank"
                            className="text-xs text-primary-400 hover:text-primary-300 flex items-center gap-1">
                        <Monitor className="w-3 h-3" /> View Live
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ─── DOCTORS ─── */}
        {tab === 'Doctors' && (
          <div className="animate-fade-in">
            <div className="page-header flex items-start justify-between">
              <div>
                <h1 className="page-title">Manage Doctors</h1>
                <p className="page-subtitle">{doctors.length} doctors registered</p>
              </div>
              <button onClick={() => setShowAddDoctor(true)} className="btn-primary">
                <Plus className="w-4 h-4" /> Add Doctor
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {doctors.map(doc => (
                <div key={doc.id} className="glass-card p-5 group hover:border-primary-600/30">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-xl flex items-center justify-center font-bold text-white text-lg"
                           style={{background:`${DEPT_COLORS_BG[doc.department] || '#2563eb'}`}}>
                        {doc.name.split(' ').find(w => w !== 'Dr.')?.charAt(0) || 'D'}
                      </div>
                      <div>
                        <div className="text-sm font-semibold text-white">{doc.name}</div>
                        <div className="text-xs text-slate-400">{doc.department}</div>
                      </div>
                    </div>
                    <button onClick={() => handleDeleteDoctor(doc.id, doc.name)}
                            className="text-slate-600 hover:text-red-400 transition-colors opacity-0 group-hover:opacity-100">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-xs text-slate-400">
                      <Clock className="w-3.5 h-3.5" />
                      {doc.availableFrom} – {doc.availableTo}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-400">
                      <AlertCircle className="w-3.5 h-3.5" />
                      ~{doc.avgConsultationTime} min / patient
                    </div>
                  </div>
                  <div className="mt-4 pt-3 flex gap-2" style={{borderTop:'1px solid rgba(255,255,255,0.05)'}}>
                    <Link to={`/live/${doc.id}`} target="_blank"
                          className="text-xs text-slate-400 hover:text-primary-400 flex items-center gap-1 transition-colors">
                      <Monitor className="w-3 h-3" /> Live Queue
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ─── ANALYTICS ─── */}
        {tab === 'Analytics' && analytics && (
          <div className="animate-fade-in space-y-8">
            <div className="page-header">
              <h1 className="page-title">Analytics Dashboard</h1>
              <p className="page-subtitle">Patient flow and performance metrics</p>
            </div>

            {/* Weekly chart */}
            <div className="glass-card p-6">
              <h3 className="text-sm font-semibold text-white mb-6 flex items-center gap-2">
                <BarChart2 className="w-4 h-4 text-slate-400" /> Weekly Patient Flow
              </h3>
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={analytics.byDay} barGap={4}>
                  <XAxis dataKey="label" tick={{fontSize:11, fill:'#64748b'}} axisLine={false} tickLine={false} />
                  <YAxis tick={{fontSize:11, fill:'#64748b'}} axisLine={false} tickLine={false} />
                  <Tooltip content={<CustomTooltip />} cursor={{fill:'rgba(255,255,255,0.02)'}} />
                  <Bar dataKey="total"     name="Total"     fill="#3b82f6" radius={[4,4,0,0]} />
                  <Bar dataKey="completed" name="Completed" fill="#22c55e" radius={[4,4,0,0]} />
                  <Bar dataKey="cancelled" name="Cancelled" fill="#ef4444" radius={[4,4,0,0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Per doctor table */}
            <div className="glass-card overflow-hidden">
              <div className="px-6 py-4" style={{borderBottom:'1px solid rgba(255,255,255,0.06)'}}>
                <h3 className="text-sm font-semibold text-white">Doctor Performance</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Doctor</th>
                      <th>Department</th>
                      <th>Total Patients</th>
                      <th>Today</th>
                      <th>Completion %</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {analytics.byDoctor.map(d => (
                      <tr key={d.doctor}>
                        <td className="font-medium text-white">{d.doctor}</td>
                        <td>
                          <span className="px-2 py-0.5 rounded text-xs" style={{background:`${DEPT_COLORS_BG[d.department] || '#2563eb'}20`, color: DEPT_COLORS_BG[d.department] || '#60a5fa'}}>
                            {d.department}
                          </span>
                        </td>
                        <td>{d.totalPatients}</td>
                        <td>{d.todayPatients}</td>
                        <td>
                          <div className="flex items-center gap-2">
                            <div className="w-24 h-1.5 rounded-full overflow-hidden" style={{background:'rgba(255,255,255,0.1)'}}>
                              <div className="h-full rounded-full" style={{width:`${d.completionRate}%`, background:'#22c55e'}} />
                            </div>
                            <span className="text-xs">{d.completionRate}%</span>
                          </div>
                        </td>
                        <td>
                          {d.todayPatients > 0
                            ? <span className="badge-in-progress">Active</span>
                            : <span className="badge-waiting">Idle</span>}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ─── ALL QUEUES ─── */}
        {tab === 'All Queues' && (
          <div className="animate-fade-in space-y-6">
            <div className="page-header">
              <h1 className="page-title">All Live Queues</h1>
              <p className="page-subtitle">Real-time view of all doctor queues</p>
            </div>
            {allQueues.map(q => (
              <div key={q.doctor.id} className="glass-card overflow-hidden">
                <div className="px-6 py-4 flex items-center justify-between"
                     style={{borderBottom:'1px solid rgba(255,255,255,0.06)'}}>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold text-white"
                         style={{background: DEPT_COLORS_BG[q.doctor.department] || '#2563eb'}}>
                      {q.doctor.department.charAt(0)}
                    </div>
                    <div>
                      <span className="text-sm font-semibold text-white">{q.doctor.name}</span>
                      <span className="text-xs text-slate-500 ml-2">{q.doctor.department}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 text-xs">
                    <span className="text-amber-400">{q.waiting.length} waiting</span>
                    <span className="text-blue-400">{q.current ? `Serving #${q.current.tokenNumber}` : 'Idle'}</span>
                    <span className="text-green-400">{q.completed} done</span>
                    <Link to={`/live/${q.doctor.id}`} target="_blank" className="btn-secondary px-3 py-1.5 text-xs">
                      <Monitor className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </div>
                {q.waiting.length === 0 && !q.current ? (
                  <div className="py-8 text-center text-slate-600 text-sm">No active tokens</div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="data-table">
                      <thead>
                        <tr><th>Token</th><th>Patient</th><th>Phone</th><th>Status</th><th>Time</th></tr>
                      </thead>
                      <tbody>
                        {[q.current, ...q.waiting].filter(Boolean).map(t => (
                          <tr key={t.id}>
                            <td><span className="font-bold text-white">#{t.tokenNumber}</span></td>
                            <td className="font-medium text-white">{t.patient?.name}</td>
                            <td>{t.patient?.phone}</td>
                            <td>
                              {t.status === 'WAITING' && <span className="badge-waiting">⏳ Waiting</span>}
                              {t.status === 'IN_PROGRESS' && <span className="badge-in-progress">▶ In Progress</span>}
                            </td>
                            <td className="text-slate-500">{new Date(t.createdAt).toLocaleTimeString()}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Doctor Modal */}
      {showAddDoctor && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setShowAddDoctor(false)}>
          <div className="modal-box">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                <Plus className="w-5 h-5 text-primary-400" /> Add New Doctor
              </h3>
              <button onClick={() => setShowAddDoctor(false)}
                      className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-white transition-colors"
                      style={{background:'rgba(255,255,255,0.06)'}}>
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleAddDoctor} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-2">Full Name *</label>
                <input id="new-doc-name" type="text" value={newDoc.name}
                  onChange={e => setNewDoc(f => ({ ...f, name: e.target.value }))}
                  placeholder="Dr. Full Name" className="input-field" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-2">Department *</label>
                <input id="new-doc-dept" type="text" value={newDoc.department}
                  onChange={e => setNewDoc(f => ({ ...f, department: e.target.value }))}
                  placeholder="e.g. Cardiology" className="input-field" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-2">Available From</label>
                  <input type="time" value={newDoc.availableFrom}
                    onChange={e => setNewDoc(f => ({ ...f, availableFrom: e.target.value }))}
                    className="input-field" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-2">Available To</label>
                  <input type="time" value={newDoc.availableTo}
                    onChange={e => setNewDoc(f => ({ ...f, availableTo: e.target.value }))}
                    className="input-field" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-2">Avg Consultation Time (min)</label>
                <input type="number" value={newDoc.avgConsultationTime} min="5" max="60"
                  onChange={e => setNewDoc(f => ({ ...f, avgConsultationTime: e.target.value }))}
                  className="input-field" />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowAddDoctor(false)} className="btn-secondary flex-1">Cancel</button>
                <button id="submit-new-doctor" type="submit" disabled={addingDoctor} className="btn-primary flex-1">
                  {addingDoctor ? <><span className="spinner" /> Adding...</> : <><Plus className="w-4 h-4" /> Add Doctor</>}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="glass-card px-4 py-3 text-xs">
      <p className="text-white font-semibold mb-1">{label}</p>
      {payload.map(p => (
        <p key={p.name} style={{color: p.fill}}>{p.name}: {p.value}</p>
      ))}
    </div>
  );
}

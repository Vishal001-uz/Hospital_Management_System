import { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { doctorService, patientService, tokenService } from '../mockData';
import toast from 'react-hot-toast';
import {
  Activity, User, Phone, Calendar, Stethoscope,
  ChevronRight, Ticket, Clock, Monitor, ArrowRight
} from 'lucide-react';
import QRCode from 'qrcode';

export default function PatientBooking() {
  const navigate  = useNavigate();
  const qrRef     = useRef(null);

  const [doctors, setDoctors]   = useState([]);
  const [step, setStep]         = useState(1); // 1=form, 2=confirm, 3=success
  const [loading, setLoading]   = useState(false);
  const [bookedToken, setBookedToken] = useState(null);

  const [form, setForm] = useState({ name: '', phone: '', age: '', doctorId: '' });
  const [selectedDoctor, setSelectedDoctor] = useState(null);
  const [queueInfo, setQueueInfo] = useState(null);
  const [qrDataUrl, setQrDataUrl] = useState('');

  useEffect(() => {
    doctorService.getAll().then(setDoctors);
  }, []);

  const handleDoctorChange = async (doctorId) => {
    setForm(f => ({ ...f, doctorId }));
    const doc = doctors.find(d => d.id === parseInt(doctorId));
    setSelectedDoctor(doc || null);
    if (doctorId) {
      const q = await (await import('../mockData')).queueService.getLive(doctorId);
      setQueueInfo(q);
    }
  };

  const DEPT_COLORS = {
    Cardiology:   'from-rose-600/20 to-red-900/10 border-rose-600/20',
    Neurology:    'from-violet-600/20 to-purple-900/10 border-violet-600/20',
    Orthopedics:  'from-amber-600/20 to-yellow-900/10 border-amber-600/20',
    Pediatrics:   'from-emerald-600/20 to-green-900/10 border-emerald-600/20',
    Dermatology:  'from-blue-600/20 to-indigo-900/10 border-blue-600/20',
  };
  const DEPT_ICON_BG = {
    Cardiology: '#dc2626', Neurology: '#7c3aed', Orthopedics: '#d97706',
    Pediatrics: '#059669', Dermatology: '#2563eb',
  };

  const validateForm = () => {
    if (!form.name.trim())    { toast.error('Please enter patient name'); return false; }
    if (!/^\d{10}$/.test(form.phone)) { toast.error('Please enter valid 10-digit phone'); return false; }
    if (!form.age || form.age < 1 || form.age > 120) { toast.error('Please enter valid age'); return false; }
    if (!form.doctorId)       { toast.error('Please select a doctor'); return false; }
    return true;
  };

  const handleConfirm = (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    setStep(2);
  };

  const handleBook = async () => {
    setLoading(true);
    try {
      // Create/find patient
      const patient = await patientService.create({ name: form.name, phone: form.phone, age: form.age });
      // Book token
      const token = await tokenService.book({ patientId: patient.id, doctorId: parseInt(form.doctorId) });
      setBookedToken({ ...token, patient });
      setStep(3);
      toast.success(`Token #${token.tokenNumber} booked successfully!`);

      // Generate QR code
      const qrData = JSON.stringify({ tokenId: token.id, tokenNumber: token.tokenNumber, doctorId: token.doctorId });
      const url = await QRCode.toDataURL(qrData, {
        width: 200, margin: 1,
        color: { dark: '#ffffff', light: '#00000000' },
      });
      setQrDataUrl(url);
    } catch (err) {
      toast.error(err.message || 'Failed to book token');
    } finally {
      setLoading(false);
    }
  };

  const dept = selectedDoctor?.department;

  return (
    <div className="min-h-screen" style={{background:'radial-gradient(ellipse at 0% 0%, rgba(59,130,246,0.06) 0%, transparent 50%), #080b14'}}>
      {/* Top nav */}
      <nav className="flex items-center justify-between px-6 py-4" style={{borderBottom:'1px solid rgba(255,255,255,0.06)'}}>
        <div className="flex items-center gap-2">
          <Activity className="w-6 h-6 text-primary-400" />
          <span className="font-bold text-white text-lg">MediQueue</span>
        </div>
        <div className="flex items-center gap-4">
          <Link to="/live" className="text-xs text-slate-400 hover:text-white flex items-center gap-1 transition-colors">
            <Monitor className="w-3.5 h-3.5" /> Live Display
          </Link>
          <Link to="/login" className="btn-secondary text-xs px-4 py-2">Staff Login →</Link>
        </div>
      </nav>

      <div className="max-w-3xl mx-auto px-4 py-10">
        {/* Header */}
        <div className="text-center mb-10 animate-fade-in">
          <span className="inline-block px-3 py-1 rounded-full text-xs font-medium mb-4"
                style={{background:'rgba(59,130,246,0.15)', color:'#60a5fa', border:'1px solid rgba(59,130,246,0.25)'}}>
            Walk-in Token Booking
          </span>
          <h1 className="text-4xl font-bold text-white mb-3">Book Your <span className="gradient-text">Queue Token</span></h1>
          <p className="text-slate-400">Skip the physical wait. Book online, arrive on time.</p>
        </div>

        {/* Steps indicator */}
        <div className="flex items-center justify-center gap-2 mb-10">
          {[1,2,3].map(s => (
            <div key={s} className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-all duration-300 ${
                step >= s ? 'text-white' : 'text-slate-600'
              }`} style={{background: step >= s ? 'linear-gradient(135deg, #3b82f6, #1d4ed8)' : 'rgba(255,255,255,0.05)'}}>
                {s}
              </div>
              {s < 3 && <div className={`w-16 h-0.5 transition-all duration-500 ${step > s ? 'bg-primary-500' : 'bg-white/10'}`} />}
            </div>
          ))}
        </div>
        <div className="flex justify-center gap-16 -mt-6 mb-10">
          <span className="text-xs text-slate-500">Details</span>
          <span className="text-xs text-slate-500">Confirm</span>
          <span className="text-xs text-slate-500">Done</span>
        </div>

        {/* Step 1: Form */}
        {step === 1 && (
          <div className="glass-card p-8 animate-slide-up">
            <form onSubmit={handleConfirm} className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-2">
                    <User className="inline w-3.5 h-3.5 mr-1" />Patient Name *
                  </label>
                  <input id="patient-name" type="text" value={form.name}
                    onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                    placeholder="Full name" className="input-field" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-2">
                    <Phone className="inline w-3.5 h-3.5 mr-1" />Phone Number *
                  </label>
                  <input id="patient-phone" type="tel" value={form.phone}
                    onChange={e => setForm(f => ({ ...f, phone: e.target.value.replace(/\D/g,'').slice(0,10) }))}
                    placeholder="10-digit mobile" className="input-field" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-2">
                    <Calendar className="inline w-3.5 h-3.5 mr-1" />Age *
                  </label>
                  <input id="patient-age" type="number" value={form.age}
                    onChange={e => setForm(f => ({ ...f, age: e.target.value }))}
                    placeholder="Age in years" min="1" max="120" className="input-field" />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-2">
                    <Stethoscope className="inline w-3.5 h-3.5 mr-1" />Select Doctor *
                  </label>
                  <select id="doctor-select" value={form.doctorId}
                    onChange={e => handleDoctorChange(e.target.value)}
                    className="input-field">
                    <option value="">Choose a doctor...</option>
                    {doctors.map(d => (
                      <option key={d.id} value={d.id}>{d.name} ({d.department})</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Doctor info card */}
              {selectedDoctor && (
                <div className={`rounded-xl p-5 bg-gradient-to-br border ${DEPT_COLORS[dept] || 'from-blue-600/10 border-blue-600/20'} animate-fade-in`}>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                         style={{background:`${DEPT_ICON_BG[dept] || '#2563eb'}30`}}>
                      <Stethoscope className="w-6 h-6" style={{color: DEPT_ICON_BG[dept] || '#60a5fa'}} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-white">{selectedDoctor.name}</p>
                      <p className="text-sm text-slate-400">{dept}</p>
                      <div className="flex items-center gap-4 mt-2">
                        <span className="text-xs text-slate-500 flex items-center gap-1">
                          <Clock className="w-3 h-3" /> {selectedDoctor.availableFrom} – {selectedDoctor.availableTo}
                        </span>
                        <span className="text-xs text-slate-500">~{selectedDoctor.avgConsultationTime} min/patient</span>
                      </div>
                    </div>
                    {queueInfo && (
                      <div className="text-right flex-shrink-0">
                        <div className="text-2xl font-bold text-white">{queueInfo.waiting.length}</div>
                        <div className="text-xs text-slate-400">waiting now</div>
                        {queueInfo.waiting.length > 0 && (
                          <div className="text-xs text-amber-400 mt-1">
                            ~{queueInfo.waiting.length * selectedDoctor.avgConsultationTime} min wait
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              )}

              <button id="book-continue" type="submit" className="btn-primary w-full">
                Continue <ChevronRight className="w-4 h-4" />
              </button>
            </form>
          </div>
        )}

        {/* Step 2: Confirm */}
        {step === 2 && (
          <div className="glass-card p-8 animate-slide-up">
            <h3 className="text-lg font-semibold text-white mb-6">Confirm Booking Details</h3>
            <div className="space-y-3 mb-8">
              {[
                { label: 'Patient Name', value: form.name },
                { label: 'Phone',        value: form.phone },
                { label: 'Age',          value: `${form.age} years` },
                { label: 'Doctor',       value: selectedDoctor?.name },
                { label: 'Department',   value: selectedDoctor?.department },
                { label: 'Timing',       value: `${selectedDoctor?.availableFrom} – ${selectedDoctor?.availableTo}` },
                { label: 'Est. Wait',    value: queueInfo ? `~${queueInfo.waiting.length * (selectedDoctor?.avgConsultationTime || 10)} min` : 'Calculating...' },
              ].map(({ label, value }) => (
                <div key={label} className="flex justify-between py-3" style={{borderBottom:'1px solid rgba(255,255,255,0.06)'}}>
                  <span className="text-sm text-slate-400">{label}</span>
                  <span className="text-sm font-medium text-white">{value}</span>
                </div>
              ))}
            </div>
            <div className="flex gap-3">
              <button onClick={() => setStep(1)} className="btn-secondary flex-1">← Back</button>
              <button id="confirm-book" onClick={handleBook} disabled={loading} className="btn-primary flex-1">
                {loading ? <><span className="spinner" /> Booking...</> : <>Confirm Booking <Ticket className="w-4 h-4" /></>}
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Success */}
        {step === 3 && bookedToken && (
          <div className="animate-bounce-in">
            <div className="glass-card p-8 text-center mb-6 glow-blue">
              <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4"
                   style={{background:'rgba(34,197,94,0.15)', border:'2px solid rgba(34,197,94,0.3)'}}>
                <Ticket className="w-10 h-10 text-green-400" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-1">Token Booked!</h2>
              <p className="text-slate-400 text-sm mb-6">Your queue token has been reserved</p>

              {/* Token number */}
              <div className="rounded-2xl p-6 mb-6" style={{background:'rgba(59,130,246,0.08)', border:'1px solid rgba(59,130,246,0.2)'}}>
                <div className="text-6xl font-black gradient-text">#{bookedToken.tokenNumber}</div>
                <div className="text-sm text-slate-400 mt-1">Your Token Number</div>
                <div className="mt-4 text-sm text-white font-medium">{bookedToken.doctor?.name}</div>
                <div className="text-xs text-slate-500">{bookedToken.doctor?.department}</div>
              </div>

              {/* QR Code */}
              {qrDataUrl && (
                <div className="mb-6 flex flex-col items-center">
                  <img src={qrDataUrl} alt="Token QR Code" className="w-36 h-36 rounded-xl" style={{background:'rgba(255,255,255,0.05)', padding:'8px'}} />
                  <p className="text-xs text-slate-500 mt-2">Scan at hospital counter</p>
                </div>
              )}

              <div className="flex gap-3">
                <Link to={`/queue/${bookedToken.id}`} className="btn-primary flex-1">
                  Track My Queue <ArrowRight className="w-4 h-4" />
                </Link>
                <button onClick={() => { setStep(1); setForm({ name:'', phone:'', age:'', doctorId:'' }); setBookedToken(null); }}
                        className="btn-secondary flex-1">
                  Book Another
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

package com.hospital.queue.doctor.service;

import com.hospital.queue.doctor.dto.DoctorRequest;
import com.hospital.queue.doctor.entity.Doctor;
import com.hospital.queue.doctor.repository.DoctorRepository;
import com.hospital.queue.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class DoctorService {

    private final DoctorRepository doctorRepository;

    public List<Doctor> getAll() {
        return doctorRepository.findAll();
    }

    public Doctor getById(Long id) {
        return doctorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id: " + id));
    }

    public Doctor create(DoctorRequest request) {
        Doctor doctor = Doctor.builder()
                .name(request.getName())
                .department(request.getDepartment())
                .availableFrom(request.getAvailableFrom())
                .availableTo(request.getAvailableTo())
                .avgConsultationTime(request.getAvgConsultationTime())
                .build();
        return doctorRepository.save(doctor);
    }

    public Doctor update(Long id, DoctorRequest request) {
        Doctor doctor = getById(id);
        doctor.setName(request.getName());
        doctor.setDepartment(request.getDepartment());
        doctor.setAvailableFrom(request.getAvailableFrom());
        doctor.setAvailableTo(request.getAvailableTo());
        doctor.setAvgConsultationTime(request.getAvgConsultationTime());
        return doctorRepository.save(doctor);
    }

    public void delete(Long id) {
        Doctor doctor = getById(id);
        doctorRepository.delete(doctor);
    }
}

import { createContext, useContext, useState, useEffect } from 'react';
import { authService } from '../mockData';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser]       = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem('hq_session');
    if (stored) {
      try {
        const session = JSON.parse(stored);
        if (session.exp > Date.now()) {
          setUser(session);
        } else {
          localStorage.removeItem('hq_session');
        }
      } catch {
        localStorage.removeItem('hq_session');
      }
    }
    setLoading(false);
  }, []);

  const login = async (username, password) => {
    const data = await authService.login(username, password);
    const session = { ...data, exp: Date.now() + 86400000 };
    localStorage.setItem('hq_session', JSON.stringify(session));
    setUser(session);
    return session;
  };

  const logout = () => {
    localStorage.removeItem('hq_session');
    setUser(null);
  };

  const isAdmin  = () => user?.role === 'ADMIN';
  const isDoctor = () => user?.role === 'DOCTOR';

  return (
    <AuthContext.Provider value={{ user, loading, login, logout, isAdmin, isDoctor }}>
      {!loading && children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};

export default AuthContext;
